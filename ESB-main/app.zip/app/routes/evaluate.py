import os
from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_from_directory, current_app
from flask_login import login_required, current_user
from werkzeug.utils import secure_filename
from werkzeug.exceptions import NotFound
from datetime import datetime
from app import db
from app.models import Document, Course, Syllabus  
from app.services.evaluate_service import extract_text_from_file, analyze_exam_content
from app.services.syllabus_service import SyllabusService


evaluate_bp = Blueprint('evaluate', __name__, url_prefix='/evaluate')

UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'pdf', 'doc', 'docx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

from flask_wtf import FlaskForm
from flask_wtf.file import FileField, FileRequired, FileAllowed
from wtforms import StringField, SubmitField
from wtforms.validators import Length

class ExamUploadForm(FlaskForm):
    title = StringField('Title', validators=[Length(max=100)], render_kw={'placeholder': 'Optional title for the exam (e.g., "Week 1 Midterm")'})
    file = FileField('Exam File', validators=[
        FileRequired(),
        FileAllowed(['pdf', 'doc', 'docx'], 'PDF, DOC, or DOCX files only!')
    ])
    submit = SubmitField('Upload Exam')




@evaluate_bp.route('/<int:course_id>/week/<int:week_num>/evaluate_exam', methods=['GET'])
@login_required
def evaluate_exam(course_id, week_num):
    course = Course.query.get_or_404(course_id)

    # Check teacher permission (example)
    if not current_user.is_teacher or course.teacher_id != current_user.id:
        flash('Access denied.', 'error')
        return redirect(url_for('courses.index'))

    # Get the exam document for this course and week
    exam_document = Document.query.filter_by(
        course_id=course_id,
        week_number=week_num,
        document_type='exam'
    ).first()

    # Prepare clos_info dictionary for CLO descriptions
    syllabus = Syllabus.query.filter_by(course_id=course_id).first()
    clo_data = syllabus.clo_data if syllabus else []

    return render_template('evaluate/evaluate_exam.html',
                        course_id=course_id,
                        week_num=week_num,
                        exam_document=exam_document,
                        clo_data=clo_data)



@login_required
@evaluate_bp.route('/<int:course_id>/week/<int:week_num>/upload_exam', methods=['GET', 'POST'])
def upload_exam(course_id, week_num):
    course = Course.query.get_or_404(course_id)
    if not current_user.is_teacher or course.teacher_id != current_user.id:
        flash('Access denied. Teachers only.', 'error')
        return redirect(url_for('courses.index'))

    form = ExamUploadForm()
    if form.validate_on_submit():
        file = form.file.data
        filename = secure_filename(file.filename)
        if not allowed_file(filename):
            flash('Invalid file type. Allowed: PDF, DOC, DOCX.', 'error')
            return render_template('evaluate/upload_exam.html', form=form, course=course, course_id=course_id, week_num=week_num)

        os.makedirs(os.path.join(current_app.root_path, UPLOAD_FOLDER), exist_ok=True)
        filepath = os.path.join(current_app.root_path, UPLOAD_FOLDER, filename)
        file.save(filepath)

        exam_document = Document.query.filter_by(
            course_id=course_id,
            week_number=week_num,
            document_type='exam'
        ).first()

        if exam_document:
            exam_document.title = form.title.data or filename
            exam_document.file_path = os.path.join(UPLOAD_FOLDER, filename)
            exam_document.file_type = filename.rsplit('.', 1)[1].lower()
            exam_document.updated_at = datetime.utcnow()
            exam_document.analysis_results = None
        else:
            exam_document = Document(
                title=form.title.data or filename,
                file_path=os.path.join(UPLOAD_FOLDER, filename),
                file_type=filename.rsplit('.', 1)[1].lower(),
                document_type='exam',
                course_id=course_id,
                week_number=week_num
            )
            db.session.add(exam_document)

        db.session.commit()
        flash('Exam uploaded successfully!', 'success')
        return redirect(url_for('evaluate.evaluate_exam', course_id=course_id, week_num=week_num))

    return render_template('evaluate/upload_exam.html', form=form, course=course, course_id=course_id, week_num=week_num)

from app.services.evaluate_service import generate_exam_analysis_pdf

@login_required
@evaluate_bp.route('/<int:course_id>/week/<int:week_num>/analyze_exam', methods=['POST'])
def analyze_exam(course_id, week_num):
    course = Course.query.get_or_404(course_id)
    if not current_user.is_teacher or course.teacher_id != current_user.id:
        return jsonify({'error': 'Access denied.'}), 403

    exam_document = Document.query.filter_by(
        course_id=course_id,
        week_number=week_num,
        document_type='exam'
    ).first()

    if not exam_document or not exam_document.file_path:
        return jsonify({'error': 'No exam file found.'}), 404

    try:
        full_filepath = os.path.join(current_app.root_path, exam_document.file_path)
        print(f"DEBUG: Full exam filepath: {full_filepath}")  # Debug file existence
        if not os.path.exists(full_filepath):
            return jsonify({'error': 'Exam file not found on disk.'}), 404

        extracted_text = extract_text_from_file(full_filepath)
        if not extracted_text:
            return jsonify({'error': 'Failed to extract text from exam file.'}), 500
        print(f"DEBUG: Extracted text length: {len(extracted_text)}")  # Debug text extraction

        # IMPROVED: Build cumulative week_data, taught_clos, objectives_summary from syllabus
        syllabus = Syllabus.query.filter_by(course_id=course_id).first()
        week_data = {}
        taught_clos = set()
        objectives_summary = []
        
        if syllabus and syllabus.weekly_plan:
            try:
                # Parse weekly_plan flexibly (str -> JSON, list -> dict by week, dict as-is)
                if isinstance(syllabus.weekly_plan, str):
                    parsed_plan = json.loads(syllabus.weekly_plan)
                    print(f"DEBUG: weekly_plan parsed from str to type: {type(parsed_plan)}")  # Debug
                else:
                    parsed_plan = syllabus.weekly_plan
                    print(f"DEBUG: weekly_plan type (raw): {type(parsed_plan)}")  # Debug
                
                print(f"DEBUG: weekly_plan sample content: {parsed_plan[:2] if isinstance(parsed_plan, list) else list(parsed_plan.items())[:2]}")  # Debug sample
                
                if isinstance(parsed_plan, dict):
                    # Dict format: {"1": {...}, "2": {...}}
                    weekly_plan = parsed_plan
                elif isinstance(parsed_plan, list):
                    # List format: [{"week": 1, "objectives": "...", "CLOs": [1]}, ...]
                    # Convert to dict keyed by week
                    weekly_plan = {}
                    for week_item in parsed_plan:
                        week_key = str(week_item.get('week') or week_item.get('week_num') or len(weekly_plan) + 1)  # Flexible key
                        weekly_plan[week_key] = {
                            'objectives': week_item.get('objectives', f'Semaine {week_key}: Objectifs non définis.'),
                            'CLOs': week_item.get('CLOs', [])  # Assume list of CLOs
                        }
                    print(f"DEBUG: Converted list to dict with keys: {list(weekly_plan.keys())}")  # Debug
                else:
                    raise ValueError(f"Unsupported weekly_plan format: {type(parsed_plan)}")
                
                # Now build cumulative data (weeks 1 to week_num)
                for w in range(1, week_num + 1):
                    week_key = str(w)
                    week_info = weekly_plan.get(week_key, {})
                    week_data[w] = week_info
                    objectives_summary.append(week_info.get('objectives', f'Semaine {w}: Objectifs non définis dans le syllabus.'))
                    if 'CLOs' in week_info:
                        taught_clos.update(week_info['CLOs'])  # Add to cumulative set (handle if CLOs are str/int)
                        taught_clos = {str(c) for c in taught_clos}  # Normalize to str
                
                print(f"DEBUG: Parsed weekly_plan keys up to week {week_num}: {list(week_data.keys())}")  # Debug
                
            except (json.JSONDecodeError, ValueError, KeyError) as parse_error:
                logger.warning(f"Error parsing weekly_plan for course {course_id}: {parse_error}. Using fallback.")
                parsed_plan = None
        else:
            logger.warning(f"No syllabus or weekly_plan for course {course_id}. Using fallback.")
            parsed_plan = None
        
        # Fallback if parsing failed or no CLOs
        if not taught_clos or not objectives_summary:
            num_taught = max(1, week_num // 2)  # e.g., week 6: CLOs 1-3
            taught_clos = set(str(i) for i in range(1, num_taught + 1))
            objectives_summary = [f'Semaine {w}: Introduction aux concepts CLO{w} (fallback, syllabus incomplet).' for w in range(1, week_num + 1)]
            week_data = {w: {'objectives': objectives_summary[w-1], 'CLOs': [w] if w <= num_taught else []} for w in range(1, week_num + 1)}
            print(f"DEBUG: Applied fallback - taught_clos: {taught_clos}, objectives count: {len(objectives_summary)}")  # Debug
        
        # Global CLOs as reference (but taught are cumulative)
        global_clos = [clo['CLO#'] for clo in (syllabus.clo_data or [])] if syllabus else []
        print(f"DEBUG: Syllabus global CLOs: {global_clos}")
        print(f"DEBUG: Cumulative taught CLOs up to week {week_num}: {taught_clos}")
        print(f"DEBUG: Objectives summary (first 2): {objectives_summary[:2]}")
        print(f"DEBUG: Week data keys: {list(week_data.keys())}")  # Debug week data

        # Analyze content (pass new params)
        # In analyze_exam route
        analysis_results = analyze_exam_content(
            extracted_text, 
            course_id=course.id, 
            week_num=week_num,  # FIXED: Add this
            course_title=course.title
        )

        if 'error' in analysis_results:
            return jsonify({'error': analysis_results['error']}), 500
        print(f"DEBUG: Analysis results keys: {list(analysis_results.keys())}")  # Debug analysis

        # Save analysis results in DB
        exam_document.analysis_results = analysis_results
        exam_document.updated_at = datetime.utcnow()
        db.session.commit()

        # Generate PDF report path
        pdf_filename = f"exam_analysis_{course.title}_week{week_num}.pdf"
        reports_dir = os.path.join(current_app.root_path, 'uploads', 'reports')
        os.makedirs(reports_dir, exist_ok=True)
        pdf_output_path = os.path.join(reports_dir, pdf_filename)
        print(f"DEBUG: PDF output path: {pdf_output_path}")  # Debug path

        # Generate PDF report with error handling
        try:
            print("DEBUG: Starting PDF generation...")  # Debug
            generate_exam_analysis_pdf(course, week_num, exam_document, analysis_results, week_data, pdf_output_path)
            print("DEBUG: PDF generation completed.")  # Debug
        except Exception as pdf_error:
            print(f"ERROR in PDF generation: {pdf_error}")  # Debug
            import traceback
            print(traceback.format_exc())  # Full error trace
            return jsonify({'error': f'PDF generation failed: {str(pdf_error)}'}), 500

        # Verify file was created
        if os.path.exists(pdf_output_path) and os.path.getsize(pdf_output_path) > 0:
            print(f"DEBUG: PDF created successfully (size: {os.path.getsize(pdf_output_path)} bytes)")  # Debug
        else:
            print(f"ERROR: PDF not created or empty at {pdf_output_path}")  # Debug
            return jsonify({'error': 'PDF generation failed - file not created.'}), 500

        # Save PDF path in DB
        exam_document.analysis_report_path = f"uploads/reports/{pdf_filename}"
        db.session.commit()

        return jsonify({'success': True, 'results': analysis_results, 'report_pdf': exam_document.analysis_report_path})

    except Exception as e:
        db.session.rollback()
        current_app.logger.error(f"Exam analysis failed: {e}")
        import traceback
        print(f"FULL ERROR TRACEBACK:\n{traceback.format_exc()}")  # Catch-all debug
        return jsonify({'error': f'Analysis failed: {str(e)}'}), 500


@login_required
@evaluate_bp.route('/download_exam/<filename>')
def download_exam(filename):
    if not current_user.is_teacher:
        raise NotFound('File not found.')

    try:
        # Extract just filename if path was passed (security)
        safe_filename = filename.split('/')[-1] if '/' in filename else filename
        return send_from_directory(os.path.join(current_app.root_path, UPLOAD_FOLDER), safe_filename)
    except NotFound:
        flash('File not found.', 'error')
        return redirect(url_for('courses.index'))

@evaluate_bp.route('/download_report/<filename>')
@login_required
def download_report(filename):
    if not current_user.is_teacher:
        abort(403)
    try:
        return send_from_directory(os.path.join(current_app.root_path, 'uploads', 'reports'), filename, as_attachment=True, download_name=filename)
    except NotFound:
        flash('Report not found.', 'error')
        return redirect(url_for('courses.index'))

