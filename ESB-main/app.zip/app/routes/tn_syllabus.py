from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, current_app
from werkzeug.utils import secure_filename
import os

from flask_login import login_required, current_user

from app import db
from app.models import Course, Syllabus, TNAA, TNAAP, TNChapter, TNSection, TNChapterAAA, TNSectionAAA, TNEvaluation, TNBibliography, TNSyllabusAdministrative
from app.services.syllabus_tn_service import SyllabusTNService

tn_syllabus_bp = Blueprint("tn_syllabus", __name__, url_prefix="/tn_syllabus")


# ---------------------------------------------------------
# helpers
# ---------------------------------------------------------
ALLOWED_EXTENSIONS = {"pdf", "doc", "docx"}

def allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

def _upload_folder():
    folder = current_app.config.get("UPLOAD_FOLDER", "uploads")
    os.makedirs(folder, exist_ok=True)
    return folder

def _ensure_teacher_owns_course(course: Course):
    if not current_user.is_authenticated or not current_user.is_teacher or course.teacher_id != current_user.id:
        flash("You do not have permission to manage this course.", "danger")
        return False
    return True

def _get_or_create_syllabus(course_id: int) -> Syllabus:
    syllabus = Syllabus.query.filter_by(course_id=course_id).first()
    if not syllabus:
        syllabus = Syllabus(course_id=course_id, syllabus_type="tn")
        db.session.add(syllabus)
        db.session.commit()
    return syllabus

def _clear_tn_normalized(syllabus: Syllabus):
    """
    Since relationships use cascade delete-orphan, clearing the relationships is enough.
    """
    # 1) AA links must go first (chapter/section link tables)
    # easiest: delete by query
    chap_ids = [c.id for c in syllabus.tn_chapters]
    if chap_ids:
        db.session.query(TNChapterAAA).filter(TNChapterAAA.chapter_id.in_(chap_ids)).delete(synchronize_session=False)
        sec_ids = db.session.query(TNSection.id).filter(TNSection.chapter_id.in_(chap_ids)).all()
        sec_ids = [x[0] for x in sec_ids]
        if sec_ids:
            db.session.query(TNSectionAAA).filter(TNSectionAAA.section_id.in_(sec_ids)).delete(synchronize_session=False)

    # 2) delete sections, chapters, AA, AAP, eval, biblio, admin
    db.session.query(TNSection).filter(TNSection.chapter_id.in_(chap_ids)).delete(synchronize_session=False)
    db.session.query(TNChapter).filter(TNChapter.syllabus_id == syllabus.id).delete(synchronize_session=False)

    db.session.query(TNAA).filter(TNAA.syllabus_id == syllabus.id).delete(synchronize_session=False)
    db.session.query(TNAAP).filter(TNAAP.syllabus_id == syllabus.id).delete(synchronize_session=False)

    db.session.query(TNEvaluation).filter(TNEvaluation.syllabus_id == syllabus.id).delete(synchronize_session=False)
    db.session.query(TNBibliography).filter(TNBibliography.syllabus_id == syllabus.id).delete(synchronize_session=False)
    db.session.query(TNSyllabusAdministrative).filter(TNSyllabusAdministrative.syllabus_id == syllabus.id).delete(synchronize_session=False)

    db.session.flush()

def _persist_tn_extraction(syllabus: Syllabus, extracted: dict):
    """
    Save extracted TN data into normalized tables:
    - tn_admin
    - tn_aa
    - tn_aap
    - tn_chapters + sections
    - mapping (AA<->chapters/sections) if present
    - tn_evaluation
    - tn_bibliography
    """
    _clear_tn_normalized(syllabus)

    # ---------------- admin ----------------
    admin = extracted.get("administrative") or {}
    if admin:
        tn_admin = TNSyllabusAdministrative(
            syllabus_id=syllabus.id,
            module_name=admin.get("module_name"),
            code_ue=admin.get("code_ue"),
            code_ecue=admin.get("code_ecue"),
            field=admin.get("field"),
            department=admin.get("department"),
            option=admin.get("option"),
            volume_presentiel=admin.get("volume_presentiel"),
            volume_personnel=admin.get("volume_personnel"),
            coefficient=admin.get("coefficient") or 0,
            credits=admin.get("credits") or 0,
            responsible=admin.get("responsible"),
            teachers=admin.get("teachers") or [],
        )
        db.session.add(tn_admin)

    # ---------------- AAA ----------------
    aaa_list = extracted.get("aaa") or []
    aa_by_number = {}
    for aa in aaa_list:
        num = aa.get("AA#")
        desc = aa.get("description")
        if not num or not desc:
            continue
        row = TNAA(syllabus_id=syllabus.id, number=int(num), description=desc)
        db.session.add(row)
        db.session.flush()  # get id
        aa_by_number[int(num)] = row

    # ---------------- AAP ----------------
    aap_list = extracted.get("aap") or []
    for a in aap_list:
        num = a.get("AAP#")
        sel = bool(a.get("selected", True))
        if not num:
            continue
        db.session.add(TNAAP(syllabus_id=syllabus.id, number=int(num), selected=sel))

    # ---------------- chapters + sections ----------------
    chapters = extracted.get("chapters") or []
    chapter_id_by_index = {}
    section_id_by_key = {}  # (chap_index, section_index) -> section_id

    for ch in chapters:
        ch_index = ch.get("chapter_index") or ch.get("index") or None
        ch_title = ch.get("chapter_title") or ch.get("chapter") or ""
        if not ch_title:
            continue
        if ch_index is None:
            # fallback: compute later by ordering
            pass

        # if missing, try best effort
        if ch_index is None:
            # place it at the end based on current count + 1
            ch_index = (len(chapter_id_by_index) + 1)

        chapter_row = TNChapter(syllabus_id=syllabus.id, index=int(ch_index), title=str(ch_title))
        db.session.add(chapter_row)
        db.session.flush()
        chapter_id_by_index[int(ch_index)] = chapter_row.id

        # sections
        sec_list = ch.get("sections") or []
        for sec in sec_list:
            sec_index = sec.get("section_index") or sec.get("index") or ""
            sec_title = sec.get("section_title") or sec.get("title") or ""
            if not sec_index or not sec_title:
                continue
            sec_row = TNSection(chapter_id=chapter_row.id, index=str(sec_index), title=str(sec_title))
            db.session.add(sec_row)
            db.session.flush()
            section_id_by_key[(int(ch_index), str(sec_index))] = sec_row.id

    # ---------------- mapping (AA -> chapter/section) ----------------
    # Your extractor sometimes outputs:
    # - chapter has "AA#" list and "AADescription"
    # - section has "AA#" list and "AADescription"
    # We'll store those in TNChapterAAA / TNSectionAAA
    for ch in chapters:
        ch_index = int(ch.get("chapter_index") or ch.get("index") or 0)
        chap_id = chapter_id_by_index.get(ch_index)
        if not chap_id:
            continue

        ch_aa_nums = ch.get("AA#") or []
        ch_aa_desc = ch.get("AADescription") or []
        if isinstance(ch_aa_nums, int):
            ch_aa_nums = [ch_aa_nums]
        if isinstance(ch_aa_desc, str):
            ch_aa_desc = [ch_aa_desc]

        for i, aa_num in enumerate(ch_aa_nums):
            try:
                aa_num = int(aa_num)
            except:
                continue
            aa_row = aa_by_number.get(aa_num)
            if not aa_row:
                continue
            desc_override = None
            if i < len(ch_aa_desc):
                desc_override = ch_aa_desc[i]
            db.session.add(TNChapterAAA(chapter_id=chap_id, aa_id=aa_row.id, description_override=desc_override))

        # sections mapping
        for sec in (ch.get("sections") or []):
            sec_index = str(sec.get("section_index") or sec.get("index") or "")
            sec_id = section_id_by_key.get((ch_index, sec_index))
            if not sec_id:
                continue

            s_aa_nums = sec.get("AA#") or []
            s_aa_desc = sec.get("AADescription") or []
            if isinstance(s_aa_nums, int):
                s_aa_nums = [s_aa_nums]
            if isinstance(s_aa_desc, str):
                s_aa_desc = [s_aa_desc]

            for i, aa_num in enumerate(s_aa_nums):
                try:
                    aa_num = int(aa_num)
                except:
                    continue
                aa_row = aa_by_number.get(aa_num)
                if not aa_row:
                    continue
                desc_override = None
                if i < len(s_aa_desc):
                    desc_override = s_aa_desc[i]
                db.session.add(TNSectionAAA(section_id=sec_id, aa_id=aa_row.id, description_override=desc_override))

    # ---------------- evaluation ----------------
    evaluation = extracted.get("evaluation") or {}
    if evaluation:
        db.session.add(TNEvaluation(
            syllabus_id=syllabus.id,
            methods=evaluation.get("methods") or [],
            criteria=evaluation.get("criteria") or [],
            measures=evaluation.get("measures") or [],
            final_grade_formula=evaluation.get("final_grade_formula") or ""
        ))

    # ---------------- bibliography ----------------
    bibliography = extracted.get("bibliography") or []
    # store as raw lines/objects (depending on your model definition)
    for b in bibliography:
        db.session.add(TNBibliography(syllabus_id=syllabus.id, reference=b))

    # Also keep a JSON snapshot (optional but useful for debugging)
    syllabus.tn_data = extracted
    syllabus.syllabus_type = "tn"

    db.session.commit()


# ---------------------------------------------------------
# pages
# ---------------------------------------------------------
@tn_syllabus_bp.get("/<int:course_id>/upload_form")
@login_required
def upload_form(course_id):
    course = Course.query.get_or_404(course_id)
    if not _ensure_teacher_owns_course(course):
        return redirect(url_for("courses.index"))
    syllabus = Syllabus.query.filter_by(course_id=course_id).first()
    return render_template("tn_syllabus/upload_syllabus.html", course=course, syllabus=syllabus)


@tn_syllabus_bp.post("/<int:course_id>/upload")
@login_required
def upload(course_id):
    course = Course.query.get_or_404(course_id)
    if not _ensure_teacher_owns_course(course):
        return redirect(url_for("courses.index"))

    f = request.files.get("file")
    if not f or f.filename.strip() == "":
        flash("Please choose a file.", "danger")
        return redirect(url_for("tn_syllabus.upload_form", course_id=course_id))

    if not allowed_file(f.filename):
        flash("Invalid file type. Allowed: PDF, DOCX.", "danger")
        return redirect(url_for("tn_syllabus.upload_form", course_id=course_id))

    filename = secure_filename(f.filename)
    path = os.path.join(_upload_folder(), filename)
    f.save(path)

    syllabus = _get_or_create_syllabus(course_id)
    syllabus.file_path = filename
    syllabus.syllabus_type = "tn"
    db.session.commit()

    flash("Syllabus uploaded successfully.", "success")
    return redirect(url_for("tn_syllabus.course_home", course_id=course_id))


@tn_syllabus_bp.get("/<int:course_id>/home")
@login_required
def course_home(course_id):
    course = Course.query.get_or_404(course_id)
    if not _ensure_teacher_owns_course(course):
        return redirect(url_for("courses.index"))

    syllabus = Syllabus.query.filter_by(course_id=course_id).first()
    pdf_url = None
    if syllabus and syllabus.file_path:
        pdf_url = url_for("tn_syllabus.uploaded_file", filename=syllabus.file_path)

    # If already extracted, we can show normalized DB content
    return render_template(
        "tn_syllabus/syllabus_home.html",
        course=course,
        syllabus=syllabus,
        pdf_url=pdf_url,
    )


@tn_syllabus_bp.get("/uploads/<path:filename>")
@login_required
def uploaded_file(filename):
    from flask import send_from_directory
    return send_from_directory(_upload_folder(), filename)


# ---------------------------------------------------------
# extraction (AJAX)
# ---------------------------------------------------------
@tn_syllabus_bp.post("/<int:course_id>/extract")
@login_required
def extract(course_id):
    course = Course.query.get_or_404(course_id)
    if not _ensure_teacher_owns_course(course):
        return jsonify({"ok": False, "error": "Unauthorized"}), 403

    syllabus = Syllabus.query.filter_by(course_id=course_id).first()
    if not syllabus or not syllabus.file_path:
        return jsonify({"ok": False, "error": "No syllabus uploaded yet."}), 400

    file_path = os.path.join(_upload_folder(), syllabus.file_path)
    if not os.path.exists(file_path):
        return jsonify({"ok": False, "error": "Uploaded file not found on server."}), 404

    try:
        extracted = SyllabusTNService.extract_tn_syllabus(file_path)
        _persist_tn_extraction(syllabus, extracted)
        return jsonify({"ok": True})
    except Exception as e:
        current_app.logger.exception("TN extraction failed")
        return jsonify({"ok": False, "error": str(e)}), 500
