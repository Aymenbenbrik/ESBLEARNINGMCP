"""
RAG (Retrieval-Augmented Generation) Service
Handles chunking, embedding, and retrieval of relevant document sections
SUPPORTS: English, French, Arabic, and all languages
"""

import re
import logging
from typing import List, Dict, Tuple
from collections import Counter
import math
import unicodedata

logger = logging.getLogger(__name__)


class RAGService:
    """Service for chunking documents and retrieving relevant sections - Multilingual"""
    
    # Language-specific stop words
    STOP_WORDS = {
        'en': {
            'the', 'is', 'at', 'which', 'on', 'and', 'a', 'an', 'as', 'are',
            'was', 'were', 'been', 'be', 'have', 'has', 'had', 'do', 'does',
            'did', 'will', 'would', 'could', 'should', 'may', 'might', 'must',
            'can', 'this', 'that', 'these', 'those', 'i', 'you', 'he', 'she',
            'it', 'we', 'they', 'what', 'who', 'when', 'where', 'why', 'how',
            'all', 'each', 'every', 'both', 'few', 'more', 'most', 'other',
            'some', 'such', 'no', 'nor', 'not', 'only', 'own', 'same', 'so',
            'than', 'too', 'very', 'from', 'with', 'about', 'into', 'through'
        },
        'fr': {
            'le', 'la', 'les', 'un', 'une', 'des', 'de', 'du', 'au', 'aux',
            'et', 'ou', 'mais', 'donc', 'car', 'ni', 'que', 'qui', 'quoi',
            'dont', 'où', 'ce', 'cet', 'cette', 'ces', 'mon', 'ton', 'son',
            'ma', 'ta', 'sa', 'mes', 'tes', 'ses', 'notre', 'votre', 'leur',
            'je', 'tu', 'il', 'elle', 'nous', 'vous', 'ils', 'elles', 'on',
            'être', 'avoir', 'faire', 'dire', 'aller', 'voir', 'savoir',
            'pouvoir', 'vouloir', 'venir', 'falloir', 'devoir', 'croire',
            'est', 'sont', 'était', 'étaient', 'sera', 'seront', 'a', 'ont',
            'avait', 'avaient', 'aura', 'auront', 'dans', 'pour', 'par',
            'sur', 'avec', 'sans', 'sous', 'vers', 'chez', 'plus', 'moins',
            'très', 'bien', 'tout', 'tous', 'toute', 'toutes', 'autre',
            'même', 'si', 'comme', 'quand', 'aussi', 'encore', 'déjà'
        },
        'ar': {
            'في', 'من', 'إلى', 'على', 'عن', 'هو', 'هي', 'هم', 'هن', 'أنا',
            'نحن', 'أنت', 'أنتم', 'أنتن', 'هذا', 'هذه', 'ذلك', 'تلك', 'التي',
            'الذي', 'التي', 'اللذان', 'اللتان', 'الذين', 'اللاتي', 'ما', 'من',
            'كان', 'يكون', 'ليس', 'لا', 'نعم', 'قد', 'لم', 'لن', 'إن', 'أن',
            'كل', 'بعض', 'غير', 'سوى', 'عند', 'لدى', 'مع', 'ضد', 'حول',
            'و', 'أو', 'ف', 'ثم', 'لكن', 'بل', 'إذا', 'لو', 'كي', 'حتى'
        }
    }
    
    def __init__(self, chunk_size: int = 1000, overlap: int = 200):
        """
        Initialize RAG service
        
        Args:
            chunk_size: Maximum characters per chunk
            overlap: Character overlap between chunks for context preservation
        """
        self.chunk_size = chunk_size
        self.overlap = overlap
    
    def detect_language(self, text: str) -> str:
        """
        Simple language detection based on character sets and common words
        
        Args:
            text: Text to analyze
            
        Returns:
            Language code: 'en', 'fr', 'ar', or 'unknown'
        """
        if not text:
            return 'unknown'
        
        # Check for Arabic characters
        arabic_chars = len(re.findall(r'[\u0600-\u06FF]', text))
        if arabic_chars > len(text) * 0.3:  # More than 30% Arabic
            return 'ar'
        
        # Check for French-specific patterns
        french_patterns = ['é', 'è', 'ê', 'à', 'ù', 'ç', 'œ']
        french_count = sum(text.lower().count(char) for char in french_patterns)
        
        # Common French words
        sample = text.lower()[:1000]
        french_words = ['le', 'la', 'les', 'de', 'des', 'et', 'dans', 'pour', 'est', 'sont']
        french_word_count = sum(1 for word in french_words if f' {word} ' in sample)
        
        if french_count > 5 or french_word_count > 3:
            return 'fr'
        
        # Default to English
        return 'en'
    
    def normalize_text(self, text: str) -> str:
        """
        Normalize text for better matching across languages
        Handles accents, diacritics, etc.
        
        Args:
            text: Text to normalize
            
        Returns:
            Normalized text
        """
        # Remove diacritics but keep base characters
        # This helps match "éducation" with "education"
        nfkd = unicodedata.normalize('NFKD', text)
        without_diacritics = ''.join([c for c in nfkd if not unicodedata.combining(c)])
        return without_diacritics
    
    def chunk_text(self, text: str, metadata: Dict = None) -> List[Dict]:
        """
        Split text into overlapping chunks with metadata
        Language-aware chunking for better context preservation
        
        Args:
            text: Text to chunk
            metadata: Optional metadata to attach to each chunk
            
        Returns:
            List of chunk dictionaries with text and metadata
        """
        if not text or len(text.strip()) == 0:
            logger.warning("Empty text provided for chunking")
            return []
        
        # Detect language
        language = self.detect_language(text)
        logger.info(f"Detected language: {language}")
        
        if len(text) <= self.chunk_size:
            return [{
                'text': text,
                'metadata': metadata or {},
                'chunk_index': 0,
                'total_chunks': 1,
                'language': language
            }]
        
        chunks = []
        start = 0
        chunk_index = 0
        
        # Language-specific sentence delimiters
        if language == 'ar':
            # Arabic uses different punctuation
            delimiters = ['。 ', '。\n', '؟ ', '؟\n', '! ', '!\n', '\n\n', '. ', '.\n']
        elif language == 'fr':
            # French has space before punctuation
            delimiters = ['. ', '.\n', ' ! ', ' !\n', ' ? ', ' ?\n', '\n\n']
        else:
            # English and default
            delimiters = ['. ', '.\n', '! ', '!\n', '? ', '?\n', '\n\n']
        
        while start < len(text):
            end = start + self.chunk_size
            
            # Try to break at sentence boundary
            if end < len(text):
                search_start = max(start, end - 200)
                best_break = None
                
                for delimiter in delimiters:
                    pos = text.rfind(delimiter, search_start, end)
                    if pos != -1:
                        best_break = pos + len(delimiter)
                        break
                
                if best_break:
                    end = best_break
            
            chunk_text = text[start:end].strip()
            
            if chunk_text:
                chunks.append({
                    'text': chunk_text,
                    'metadata': metadata or {},
                    'chunk_index': chunk_index,
                    'start_pos': start,
                    'end_pos': end,
                    'language': language
                })
                chunk_index += 1
            
            # Move start with overlap
            start = end - self.overlap if end < len(text) else end
        
        # Update total_chunks in all chunks
        for chunk in chunks:
            chunk['total_chunks'] = len(chunks)
        
        logger.info(f"Created {len(chunks)} chunks from {len(text)} characters ({language})")
        return chunks
    
    def tokenize_multilingual(self, text: str, language: str = 'en') -> List[str]:
        """
        Tokenize text in a language-aware manner
        
        Args:
            text: Text to tokenize
            language: Language code
            
        Returns:
            List of tokens
        """
        # Normalize text first
        normalized = self.normalize_text(text.lower())
        
        if language == 'ar':
            # Arabic: use Unicode word boundaries
            tokens = re.findall(r'[\u0600-\u06FF]+', normalized)
        elif language in ['en', 'fr']:
            # Latin scripts: alphanumeric words of 3+ chars
            tokens = re.findall(r'\b[a-zA-Z0-9]{3,}\b', normalized)
        else:
            # General Unicode word matching
            tokens = re.findall(r'\w{3,}', normalized, re.UNICODE)
        
        return tokens
    
    def create_simple_embedding(self, text: str, language: str = None) -> Dict[str, float]:
        """
        Create simple TF-IDF-like embedding (multilingual)
        
        Args:
            text: Text to embed
            language: Optional language code (auto-detected if None)
            
        Returns:
            Dictionary of word -> frequency score
        """
        if language is None:
            language = self.detect_language(text)
        
        # Tokenize based on language
        words = self.tokenize_multilingual(text, language)
        
        # Get language-specific stop words
        stop_words = self.STOP_WORDS.get(language, self.STOP_WORDS['en'])
        
        # Filter stop words (normalize them too)
        normalized_stops = {self.normalize_text(w.lower()) for w in stop_words}
        words = [w for w in words if self.normalize_text(w.lower()) not in normalized_stops]
        
        # Calculate term frequency
        word_count = Counter(words)
        total_words = len(words)
        
        if total_words == 0:
            return {}
        
        # Normalize frequencies
        embedding = {word: count / total_words for word, count in word_count.items()}
        
        return embedding
    
    def calculate_similarity(self, embedding1: Dict[str, float], embedding2: Dict[str, float]) -> float:
        """
        Calculate cosine similarity between two embeddings
        Works with any language
        
        Args:
            embedding1: First embedding
            embedding2: Second embedding
            
        Returns:
            Similarity score (0-1)
        """
        if not embedding1 or not embedding2:
            return 0.0
        
        # Get common words
        common_words = set(embedding1.keys()) & set(embedding2.keys())
        
        if not common_words:
            return 0.0
        
        # Calculate dot product
        dot_product = sum(embedding1[word] * embedding2[word] for word in common_words)
        
        # Calculate magnitudes
        magnitude1 = math.sqrt(sum(v**2 for v in embedding1.values()))
        magnitude2 = math.sqrt(sum(v**2 for v in embedding2.values()))
        
        if magnitude1 == 0 or magnitude2 == 0:
            return 0.0
        
        # Cosine similarity
        similarity = dot_product / (magnitude1 * magnitude2)
        
        return max(0.0, min(1.0, similarity))
    
    def find_relevant_chunks(
        self,
        query: str,
        chunks: List[Dict],
        top_k: int = 5,
        min_similarity: float = 0.0
    ) -> List[Tuple[Dict, float]]:
        """
        Find most relevant chunks for a query (multilingual)
        
        Args:
            query: Search query (any language)
            chunks: List of chunk dictionaries
            top_k: Number of top chunks to return
            min_similarity: Minimum similarity threshold
            
        Returns:
            List of (chunk, similarity_score) tuples, sorted by relevance
        """
        if not chunks:
            logger.warning("No chunks provided for relevance search")
            return []
        
        # Detect query language
        query_lang = self.detect_language(query)
        logger.info(f"Query language: {query_lang}")
        
        # Create query embedding
        query_embedding = self.create_simple_embedding(query, query_lang)
        
        if not query_embedding:
            logger.warning("Empty query embedding, returning first chunks")
            return [(chunk, 0.0) for chunk in chunks[:top_k]]
        
        # Calculate similarity for each chunk
        chunk_scores = []
        for chunk in chunks:
            chunk_lang = chunk.get('language', query_lang)
            chunk_embedding = self.create_simple_embedding(chunk['text'], chunk_lang)
            similarity = self.calculate_similarity(query_embedding, chunk_embedding)
            
            if similarity >= min_similarity:
                chunk_scores.append((chunk, similarity))
        
        # Sort by similarity (descending)
        chunk_scores.sort(key=lambda x: x[1], reverse=True)
        
        # Return top k
        top_chunks = chunk_scores[:top_k]
        
        logger.info(f"Found {len(top_chunks)} relevant chunks (top {top_k} from {len(chunks)})")
        if top_chunks:
            logger.info(f"Top similarity score: {top_chunks[0][1]:.3f}")
            logger.info(f"Top chunk language: {top_chunks[0][0].get('language', 'unknown')}")
        
        return top_chunks
    
    def prepare_context_from_chunks(
        self,
        relevant_chunks: List[Tuple[Dict, float]],
        max_chars: int = 8000,
        include_scores: bool = False
    ) -> str:
        """
        Combine relevant chunks into a context string (multilingual)
        
        Args:
            relevant_chunks: List of (chunk, score) tuples
            max_chars: Maximum characters in final context
            include_scores: Whether to include similarity scores in output
            
        Returns:
            Formatted context string
        """
        if not relevant_chunks:
            return ""
        
        context_parts = []
        current_length = 0
        
        for i, (chunk, score) in enumerate(relevant_chunks):
            metadata = chunk.get('metadata', {})
            chunk_text = chunk['text']
            chunk_lang = chunk.get('language', 'unknown')
            
            # Build chunk header
            header_parts = []
            if metadata.get('title'):
                header_parts.append(f"Source: {metadata['title']}")
            if metadata.get('source_id'):
                header_parts.append(f"[{metadata['source_id']}]")
            if metadata.get('source_type'):
                header_parts.append(f"Type: {metadata['source_type']}")
            header_parts.append(f"Language: {chunk_lang}")
            if include_scores:
                header_parts.append(f"Relevance: {score:.2f}")
            
            header = " | ".join(header_parts) if header_parts else f"Chunk {i+1}"
            
            # Format chunk
            chunk_formatted = f"{header}\n{chunk_text}\n---"
            
            # Check if we exceed max length
            if current_length + len(chunk_formatted) > max_chars:
                # Try to fit partial chunk
                remaining = max_chars - current_length
                if remaining > 200:
                    partial_text = chunk_text[:remaining-len(header)-20] + "..."
                    chunk_formatted = f"{header}\n{partial_text}\n---"
                    context_parts.append(chunk_formatted)
                break
            
            context_parts.append(chunk_formatted)
            current_length += len(chunk_formatted)
        
        return "\n\n".join(context_parts)


# ============================================
# FILE 2: app/services/rag_service.py
# UPDATED process_documents_for_rag() function
# ============================================

def process_documents_for_rag(
    attachments_texts: List[str],
    attachments_metadata: List[Dict],
    query_context: str,
    top_k_per_doc: int = 3,
    max_total_chunks: int = 10,
    max_context_chars: int = 12000,
    activity_patterns: Dict = None  # ✅ ADD THIS LINE
) -> Tuple[str, List[Dict]]:
    """
    Main RAG processing function: chunk documents and retrieve relevant sections
    MULTILINGUAL SUPPORT: Works with English, French, Arabic, and all languages
    
    NEW: activity_patterns parameter enables activity-guided retrieval weighting
    
    Args:
        attachments_texts: List of document texts (any language)
        attachments_metadata: List of metadata dicts for each document
        query_context: Context to find relevant chunks (any language)
        top_k_per_doc: How many chunks to retrieve per document
        max_total_chunks: Maximum total chunks across all documents
        max_context_chars: Maximum characters in final context
        activity_patterns: Optional dict from extract_activity_patterns() for weighted retrieval
        
    Returns:
        Tuple of (formatted_context_string, updated_metadata_list)
    """
    rag = RAGService(chunk_size=1200, overlap=200)
    
    all_chunks = []
    languages_detected = set()
    
    # Process each document
    for i, (text, metadata) in enumerate(zip(attachments_texts, attachments_metadata)):
        source_id = f"SRC{i+1}"
        
        # Add source_id to metadata
        doc_metadata = metadata.copy()
        doc_metadata['source_id'] = source_id
        
        # ✅ MARK ACTIVITY FILES
        is_activity = (metadata.get('source_type') == 'activity' or 
                      'activity' in metadata.get('title', '').lower())
        doc_metadata['is_activity'] = is_activity
        
        # Chunk the document (language auto-detected)
        chunks = rag.chunk_text(text, metadata=doc_metadata)
        
        # Track languages
        for chunk in chunks:
            lang = chunk.get('language', 'unknown')
            languages_detected.add(lang)
        
        logger.info(f"Document {source_id} ({metadata.get('title', 'Unknown')}): {len(chunks)} chunks")
        
        all_chunks.extend(chunks)
    
    logger.info(f"Languages detected in documents: {languages_detected}")
    
    if not all_chunks:
        logger.warning("No chunks created from documents")
        return "", []
    
    # ✅ SCORE CHUNKS WITH ACTIVITY WEIGHTING
    scored_chunks = []
    
    for chunk in all_chunks:
        # Base relevance to query
        query_embedding = rag.create_simple_embedding(query_context)
        chunk_embedding = rag.create_simple_embedding(chunk['text'])
        base_similarity = rag.calculate_similarity(query_embedding, chunk_embedding)
        
        # ✅ Activity pattern weighting
        activity_score = 0.0
        if activity_patterns and chunk['metadata'].get('is_activity'):
            activity_score = _score_chunk_by_activity_patterns(
                chunk['text'],
                activity_patterns
            )
        
        # Combined score: 60% base relevance + 40% activity alignment
        total_score = (base_similarity * 0.6) + (activity_score * 0.4)
        
        chunk['score'] = total_score
        chunk['activity_score'] = activity_score  # ✅ TRACK FOR TRANSPARENCY
        scored_chunks.append(chunk)
    
    # Sort by combined score
    scored_chunks.sort(key=lambda x: x['score'], reverse=True)
    
    logger.info(f"✅ Scored {len(scored_chunks)} chunks with activity weighting")
    
    # Get top chunks
    top_chunks = scored_chunks[:max_total_chunks]
    
    # Convert back to relevant_chunks format for context preparation
    relevant_chunks = [(chunk, chunk['score']) for chunk in top_chunks]
    
    # Prepare formatted context
    formatted_context = rag.prepare_context_from_chunks(
        relevant_chunks=relevant_chunks,
        max_chars=max_context_chars,
        include_scores=False
    )
    
    # Collect unique sources used
    sources_used = []
    seen_sources = set()
    
    for chunk, score in relevant_chunks:
        source_id = chunk['metadata'].get('source_id')
        if source_id and source_id not in seen_sources:
            sources_used.append(chunk['metadata'])
            seen_sources.add(source_id)
    
    logger.info(f"RAG Context: {len(formatted_context)} chars from {len(sources_used)} sources")
    logger.info(f"Languages in final context: {languages_detected}")
    
    if activity_patterns:
        logger.info(f"🎯 Activity weighting applied - prioritized relevant activity content")
    
    return formatted_context, sources_used


# ✅ ADD THIS HELPER FUNCTION AT END OF FILE
def _score_chunk_by_activity_patterns(chunk_text: str, activity_patterns: Dict) -> float:
    """
    Score how well chunk matches activity patterns (0-1).
    Higher score = better match to activity keywords.
    
    Args:
        chunk_text: Text to score
        activity_patterns: Dict with 'keywords_pool' key
        
    Returns:
        Score from 0.0 to 1.0
    """
    if not activity_patterns or not activity_patterns.get('keywords_pool'):
        return 0.0
    
    keywords_pool = activity_patterns['keywords_pool']
    chunk_lower = chunk_text.lower()
    keyword_matches = 0
    
    for keyword in keywords_pool.keys():
        if keyword in chunk_lower:
            keyword_matches += 1
    
    score = keyword_matches / len(keywords_pool) if keywords_pool else 0.0
    return min(score, 1.0)