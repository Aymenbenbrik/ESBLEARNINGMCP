import os
import json
import re
import requests
from flask import current_app
from app.services.file_service import get_file_path, extract_text_from_file
from app.models import Chapter, Document, Course
from flask_login import current_user
from typing import List, Dict

# Import RAG service
from app.services.rag_service import process_documents_for_rag

from app.services.evaluate_service import (
       extract_questions_from_text,
       classify_questions_clo,
       classify_questions_bloom,
       normalize_question_keys
   )

# ============================================
# NEW HELPER FUNCTION: Build Activity-Aware Prompt
# ============================================


# ============================================
# AI_SERVICE.PY - RAG-Enhanced generate_quiz_questions
# ============================================
def build_quiz_prompt(
    num_mcq, num_open, 
    week_content, clo_text, attachments_text,
    bloom_distribution, difficulty_distribution,
    language='en'
):
    """
    Simple quiz generation prompt - REMPLACE build_activity_aware_prompt()
    
    Args:
        num_mcq: Number of MCQ questions
        num_open: Number of open-ended questions
        week_content: Week learning objectives and context
        clo_text: Formatted CLO descriptions
        attachments_text: RAG-retrieved course materials
        bloom_distribution: Dict with bloom percentages
        difficulty_distribution: Dict with difficulty percentages
        language: Language code (en, fr, ar)
    
    Returns:
        Formatted user prompt for the AI model
    """
    
    total = num_mcq + num_open
    
    bloom_text = "\n".join([
        f"- {level}: {pct}% (~{int(pct/100*total)} q)"
        for level, pct in bloom_distribution.items()
    ])
    
    difficulty_text = "\n".join([
        f"- {level}: {pct}% (~{int(pct/100*total)} q)"
        for level, pct in difficulty_distribution.items()
    ])
    
    prompt = f"""Generate EXACTLY {num_mcq} MCQ + {num_open} open-ended = {total} total questions.

**COURSE MATERIALS:**
{attachments_text}

**CLOs (Course Learning Outcomes):**
{clo_text}

**CONTEXT:**
{week_content}

**BLOOM DISTRIBUTION (REQUIRED - apply independently):**
{bloom_text}

**DIFFICULTY DISTRIBUTION (REQUIRED - apply independently):**
{difficulty_text}

**MCQ FORMAT:**
Each MCQ must have:
- question: The question text
- choice_a, choice_b, choice_c: Three answer options (all plausible, one correct)
- correct_choice: A, B, or C
- explanation: Why this answer is correct
- clo: Which CLO this tests (e.g., "CLO 1")
- bloom_level: Bloom's level (remember, understand, apply, analyze, evaluate, create)
- difficulty_level: easy, medium, or hard
- source_id: SRC1, SRC2, etc. (from materials above)
- source_page: Exact location (e.g., "Section 2.1")
- source_text: Direct quote from material (1-2 sentences)

**OPEN-ENDED FORMAT:**
Each open-ended question must have:
- question: The question text
- question_type: "open_ended"
- open_ended_type: short_answer, essay, explanation, problem_solving, description, or discussion
- model_answer: Expected/model answer
- evaluation_criteria: List of grading criteria
- grading_rubric: How to grade this answer
- clo: Which CLO this tests
- bloom_level: Bloom's level
- difficulty_level: easy, medium, or hard
- explanation: Grading guidance
- source_id: SRC1, SRC2, etc.
- source_page: Exact location
- source_text: Direct quote from material

**CRITICAL REQUIREMENTS:**
1. Generate EXACTLY {num_mcq} MCQ and {num_open} open-ended ({total} total) - NO MORE, NO LESS
2. Apply Bloom and Difficulty distributions independently (don't force exact match per question)
3. ALL questions must reference source materials (source_id, source_page, source_text REQUIRED)
4. NEVER use "N/A" for source fields - always provide actual references
5. source_page MUST include section/page number AND language
6. source_text MUST be direct quotes (1-2 sentences max) from provided context
7. Questions must be in SAME language as materials
8. Output MUST be valid, parseable JSON only
9. Each question must have ALL required fields

**OUTPUT: Valid JSON only**
{{
  "questions": [
    {{
      "question_type": "mcq",
      "question": "Question text here",
      "choice_a": "Option A",
      "choice_b": "Option B",
      "choice_c": "Option C",
      "correct_choice": "A",
      "clo": "CLO 1",
      "bloom_level": "understand",
      "difficulty_level": "medium",
      "explanation": "Why A is correct",
      "source_id": "SRC1",
      "source_page": "Section 2.1",
      "source_text": "Relevant quote from material"
    }},
    {{
      "question_type": "open_ended",
      "question": "Question text here",
      "open_ended_type": "explanation",
      "model_answer": "Expected answer",
      "evaluation_criteria": ["Criterion 1", "Criterion 2", "Criterion 3"],
      "grading_rubric": "How to score this",
      "clo": "CLO 2",
      "bloom_level": "apply",
      "difficulty_level": "medium",
      "explanation": "Grading guidance",
      "source_id": "SRC2",
      "source_page": "Section 3.2",
      "source_text": "Relevant quote from material"
    }}
  ]
}}

IMPORTANT: Return ONLY valid JSON. No extra text."""

    return prompt

def generate_quiz_questions(
    week_content: str,
    clos: list,
    attachments_texts: list,
    num_mcq: int = 8,
    num_open: int = 4,
    num_questions: int = None,
    difficulty: str = 'medium',
    attachments_metadata: list = None,
    clo_distribution: dict = None,
    bloom_distribution: dict = None,
    difficulty_distribution: dict = None,
    question_similarity: int = 40,
    variation_mode: str = 'standard',
    activity_patterns: dict = None
) -> dict:
    """
    Generate high-quality quiz questions with TWO constraints:
    1. QUIZ SETUP: num_mcq, num_open, bloom_distribution, clo_distribution, difficulty_distribution
    2. ACTIVITY FILE: Inspire from question types, Bloom levels, CLOs in activity
    
    The AI will:
    - Generate EXACTLY num_mcq MCQ and num_open open-ended (from setup)
    - Use the SAME Bloom levels as activity when possible
    - Use the SAME CLOs as activity when possible
    - Use the SAME question types as activity
    
    Returns dict with:
    - 'questions': List of validated question dicts with activity alignment tracking
    - 'mcq_count': Number of MCQ questions generated
    - 'open_count': Number of open-ended questions generated
    - 'sources_used': List of source metadata
    """
    api_key = current_app.config.get('GROQ_API_KEY')
    if not api_key:
        raise ValueError("Groq API key not configured")

    model = current_app.config.get('GROQ_LLAMA_MODEL', 'llama-3.3-70b-versatile')

    # Handle backward compatibility
    if num_questions and not (num_mcq or num_open):
        num_mcq = num_questions
        num_open = 0
    
    total_questions = num_mcq + num_open
    
    if total_questions < 3:
        raise ValueError("Total questions must be at least 3")

    # Build CLO text from CLO list
    if clos:
        clo_text = "\n".join([
            f"CLO {c.get('CLO#', 'N/A')}: {c.get('CLO Description', c.get('Description', ''))[:150]}"
            for c in clos
        ])
    else:
        clo_text = "No CLOs provided."

    # ============================================
    # RAG PROCESSING
    # ============================================
    
    attachments_text = ""
    sources_map = {}
    
    if attachments_texts and attachments_metadata:
        current_app.logger.info(f"🔍 RAG: Processing {len(attachments_texts)} documents")
        
        query_context = f"""
        {week_content}
        
        Learning Outcomes:
        {clo_text}
        """
        
        try:
            from app.services.rag_service import process_documents_for_rag
            rag_context, sources_used = process_documents_for_rag(
                attachments_texts=attachments_texts,
                attachments_metadata=attachments_metadata,
                query_context=query_context,
                top_k_per_doc=3,
                max_total_chunks=10,
                max_context_chars=12000,
                activity_patterns=activity_patterns
            )
            
            attachments_text = rag_context
            
            for source in sources_used:
                source_id = source.get('source_id', 'SRC1')
                sources_map[source_id] = source
            
            current_app.logger.info(f"✅ RAG: Retrieved {len(sources_used)} relevant sources")
            
        except Exception as e:
            current_app.logger.error(f"❌ RAG processing failed: {str(e)}")
            
            attachments_with_sources = []
            for i, (text, meta) in enumerate(zip(attachments_texts, attachments_metadata)):
                source_id = f"SRC{i+1}"
                sources_map[source_id] = meta
                truncated_text = text[:4000]
                source_type = meta.get('source_type', 'material')
                attachments_with_sources.append(f"""[{source_id}] {meta.get('title', 'Doc')} ({source_type})
{truncated_text}
---""")
            
            attachments_text = "\n".join(attachments_with_sources)[:12000]
    else:
        attachments_text = "No materials provided"
        current_app.logger.warning("⚠️  No attachments provided for quiz generation")

    # ============================================
    # BUILD SYSTEM PROMPT (UPDATED FOR ACTIVITY STYLE)
    # ============================================
    
    system_prompt = f"""You are an expert educational assessment designer creating high-quality quiz questions.

CRITICAL: MATCH ACTIVITY FILE PHRASING AND STYLE

Your questions MUST:
1. Use the SAME question openers as the activity file
2. Use vocabulary from the activity file
3. Mimic the tone, language, and phrasing style
4. Reference the question EXAMPLES provided - learn their style!

For example:
- If activity uses "Qu'est-ce que..." → Your MCQ must also use "Qu'est-ce que..."
- If activity uses "Expliquez comment..." → Your open-ended must use "Expliquez comment..."
- If activity uses French terminology → Your questions use SAME French terminology

CRITICAL REQUIREMENTS:
1. Generate EXACTLY {num_mcq} MCQ + {num_open} Open-Ended = {total_questions} total questions
2. Apply CLO, Bloom, and Difficulty distributions INDEPENDENTLY
3. Similarity: {question_similarity}% | Variation Mode: {variation_mode}

MCQ FORMAT:
- 3 options (A, B, C) - all plausible but only 1 correct
- Must include: correct_choice (A/B/C), explanation, source references

OPEN-ENDED FORMAT:
- Types: short_answer, essay, explanation, problem_solving, description, discussion
- Must include: model_answer, evaluation_criteria (list), grading_rubric

SOURCE REQUIREMENTS:
- source_id: MUST be SRC1, SRC2, SRC3, etc.
- source_page: MUST specify exact location
- source_text: MUST be 1-2 sentence direct quote
- NEVER use "N/A"

LANGUAGE:
- Detect the language of the activity file
- Generate ALL questions in the SAME language
- Use the SAME terminology and vocabulary"""

    # ============================================
    # BUILD USER PROMPT USING NEW FUNCTION
    # ============================================
    
    language = rag.detect_language(attachments_text) if hasattr(rag, 'detect_language') else 'en'
    logger.info(f"Detected language: {language}")
    
    # Use the NEW simple prompt builder INSTEAD of build_activity_aware_prompt()
    user_prompt = build_quiz_prompt(
        num_mcq=num_mcq,
        num_open=num_open,
        week_content=week_content,
        clo_text=clo_text,
        attachments_text=attachments_text,
        bloom_distribution=bloom_distribution,
        difficulty_distribution=difficulty_distribution,
        language=language
    )
    
    logger.info(f"✓ Prompt built ({len(user_prompt)} chars)")

    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }

    payload = {
        "model": model,
        "messages": [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ],
        "temperature": 0.7,
        "max_tokens": 6000,  # Reduced from 8000 to minimize token usage and rate limiting
        "response_format": {"type": "json_object"}
    }

    # ============================================
    # API REQUEST WITH RETRY LOGIC FOR RATE LIMITING
    # ============================================
    
    max_retries = 3
    retry_delay = 5  # seconds
    attempt = 0
    response = None
    
    try:
        current_app.logger.info(f"🤖 Sending request to AI with COMBINED constraints:")
        current_app.logger.info(f"📊 Setup: {num_mcq} MCQ + {num_open} Open-Ended")
        current_app.logger.info(f"🎯 Activity: {activity_patterns.get('questions_count', 0) if activity_patterns else 0} questions")
        
        while attempt < max_retries:
            try:
                response = requests.post(url, headers=headers, json=payload, timeout=30)
                
                # Handle rate limiting (429)
                if response.status_code == 429:
                    attempt += 1
                    if attempt < max_retries:
                        wait_time = retry_delay * attempt
                        current_app.logger.warning(f"⚠️  Rate limited (429). Retrying in {wait_time}s (attempt {attempt}/{max_retries})")
                        import time
                        time.sleep(wait_time)
                        continue
                    else:
                        current_app.logger.error(f"❌ Rate limited after {max_retries} attempts")
                        raise ValueError("API rate limited. Please try again in a few minutes.")
                
                response.raise_for_status()
                break
                
            except requests.exceptions.Timeout:
                attempt += 1
                if attempt < max_retries:
                    current_app.logger.warning(f"⚠️  Request timeout. Retrying (attempt {attempt}/{max_retries})")
                    import time
                    time.sleep(retry_delay)
                    continue
                else:
                    raise ValueError("API request timed out after multiple attempts")
                    
            except requests.exceptions.ConnectionError as e:
                attempt += 1
                if attempt < max_retries:
                    current_app.logger.warning(f"⚠️  Connection error: {str(e)}. Retrying (attempt {attempt}/{max_retries})")
                    import time
                    time.sleep(retry_delay)
                    continue
                else:
                    raise ValueError(f"Connection error: {str(e)}")

        data = response.json()
        generated_text = data['choices'][0]['message']['content'].strip()

        # Parse JSON response
        try:
            parsed = json.loads(generated_text)
        except json.JSONDecodeError:
            current_app.logger.warning("⚠️  JSON parsing failed, attempting regex extraction")
            json_match = re.search(r'\{.*\}', generated_text, re.DOTALL)
            if json_match:
                parsed = json.loads(json_match.group(0))
            else:
                raise ValueError("Invalid JSON response from AI")

        questions = parsed.get('questions', [])

        if len(questions) < 3:
            raise ValueError(f"Only {len(questions)} questions generated, minimum 3 required")

        current_app.logger.info(f"✅ AI returned {len(questions)} questions")

        # ============================================
        # SCORE EACH QUESTION FOR ACTIVITY ALIGNMENT
        # ============================================
        
        validated_questions = []
        mcq_count = 0
        open_count = 0

        for q in questions:
            question_type = q.get('question_type', 'mcq').lower()
            
            if not q.get('question') or len(q.get('question', '')) < 10:
                current_app.logger.warning(f"⚠️  Skipping question: invalid or missing text")
                continue
            
            # Build base validated question
            validated_q = {
                'question': q['question'].strip(),
                'question_type': question_type,
                'clo': format_clo_number(q.get('clo', clos[0].get('CLO#', 'CLO 1') if clos else 'CLO 1')),
                'bloom_level': q.get('bloom_level', 'understand').lower(),
                'difficulty_level': q.get('difficulty_level', 'medium').lower(),
                'explanation': q.get('explanation', 'Based on course materials').strip(),
                'source_id': q.get('source_id', 'SRC1').strip(),
                'source_page': q.get('source_page', 'Section 1').strip(),
                'source_text': q.get('source_text', 'Reference material').strip()
            }
            
            # Validate Bloom, Difficulty, and Source fields
            if validated_q['bloom_level'] not in ['remember', 'understand', 'apply', 'analyze', 'evaluate', 'create']:
                validated_q['bloom_level'] = 'understand'
            if validated_q['difficulty_level'] not in ['easy', 'medium', 'hard']:
                validated_q['difficulty_level'] = 'medium'
            if validated_q['source_id'] == 'N/A' or not validated_q['source_id']:
                validated_q['source_id'] = 'SRC1'
            if validated_q['source_page'] == 'N/A' or not validated_q['source_page']:
                validated_q['source_page'] = 'Section 1'
            if validated_q['source_text'] == 'N/A' or not validated_q['source_text']:
                validated_q['source_text'] = 'Reference material'
            
            # ============================================
            # SCORE ACTIVITY ALIGNMENT (STRUCTURAL)
            # ============================================
            
            if activity_patterns and activity_patterns.get('questions_count', 0) > 0:
                is_inspired, score, details = score_question_activity_alignment(validated_q, activity_patterns)
                validated_q['_activity_inspired'] = is_inspired
                validated_q['_activity_alignment_score'] = score
                validated_q['_activity_alignment_details'] = details
            else:
                validated_q['_activity_inspired'] = False
                validated_q['_activity_alignment_score'] = 0
                validated_q['_activity_alignment_details'] = "No activity file"
            
            # ============================================
            # MCQ VALIDATION
            # ============================================
            
            if question_type == 'mcq':
                if not all(k in q for k in ['choice_a', 'choice_b', 'choice_c', 'correct_choice']):
                    current_app.logger.warning(f"⚠️  Skipping MCQ: missing choice fields")
                    continue
                
                validated_q['choice_a'] = q['choice_a'].strip()
                validated_q['choice_b'] = q['choice_b'].strip()
                validated_q['choice_c'] = q['choice_c'].strip()
                validated_q['correct_choice'] = str(q['correct_choice']).upper().strip()
                
                if not all([validated_q['choice_a'], validated_q['choice_b'], validated_q['choice_c']]):
                    current_app.logger.warning(f"⚠️  Skipping MCQ: empty choices")
                    continue
                
                if validated_q['correct_choice'] not in ['A', 'B', 'C']:
                    validated_q['correct_choice'] = 'A'
                
                mcq_count += 1
            
            # ============================================
            # OPEN-ENDED VALIDATION
            # ============================================
            
            elif question_type == 'open_ended':
                if not q.get('model_answer') or len(q.get('model_answer', '')) < 10:
                    current_app.logger.warning(f"⚠️  Skipping open-ended: missing or short model answer")
                    continue
                
                bloom_level = validated_q['bloom_level']
                suggested_type = get_open_ended_type_for_bloom(bloom_level)
                open_ended_type = q.get('open_ended_type', suggested_type).lower()
                valid_types = ['short_answer', 'essay', 'code_correction', 'explanation', 'problem_solving', 'description', 'discussion']
                
                if open_ended_type not in valid_types:
                    open_ended_type = suggested_type
                
                validated_q['open_ended_type'] = open_ended_type
                validated_q['model_answer'] = q['model_answer'].strip()
                validated_q['evaluation_criteria'] = q.get('evaluation_criteria', ['Check understanding of key concepts'])
                
                if isinstance(validated_q['evaluation_criteria'], str):
                    validated_q['evaluation_criteria'] = [validated_q['evaluation_criteria']]
                
                validated_q['evaluation_criteria'] = [c.strip() for c in validated_q['evaluation_criteria'] if c.strip()]
                
                if not validated_q['evaluation_criteria']:
                    validated_q['evaluation_criteria'] = ['Assess based on model answer']
                
                validated_q['grading_rubric'] = q.get('grading_rubric', 'Assess based on model answer').strip()
                
                open_count += 1
            
            else:
                current_app.logger.warning(f"⚠️  Skipping question: unknown type '{question_type}'")
                continue
            
            if not validated_q.get('question') or not validated_q.get('question_type'):
                current_app.logger.warning(f"⚠️  Skipping question: missing required fields")
                continue
            
            validated_questions.append(validated_q)

        # Limit to requested total
        validated_questions = validated_questions[:total_questions]

        # ============================================
        # LOG COMPLIANCE
        # ============================================
        
        bloom_counts = {}
        difficulty_counts = {}
        clo_counts = {}
        activity_inspired_count = 0
        
        for q in validated_questions:
            bloom_counts[q['bloom_level']] = bloom_counts.get(q['bloom_level'], 0) + 1
            difficulty_counts[q['difficulty_level']] = difficulty_counts.get(q['difficulty_level'], 0) + 1
            clo_counts[q['clo']] = clo_counts.get(q['clo'], 0) + 1
            if q.get('_activity_inspired'):
                activity_inspired_count += 1
        
        current_app.logger.info(f"✅ Generated {len(validated_questions)} questions ({mcq_count} MCQ, {open_count} open-ended)")
        current_app.logger.info(f"📊 Bloom: {bloom_counts}")
        current_app.logger.info(f"📊 Difficulty: {difficulty_counts}")
        current_app.logger.info(f"📊 CLO: {clo_counts}")
        current_app.logger.info(f"🎯 Activity-Aligned: {activity_inspired_count}/{len(validated_questions)} questions")
        
        return {
            'questions': validated_questions,
            'sources_used': list(sources_map.values()),
            'mcq_count': mcq_count,
            'open_count': open_count
        }

    except Exception as e:
        current_app.logger.error(f"❌ Error generating questions: {str(e)}")
        import traceback
        current_app.logger.error(traceback.format_exc())
        
        # Provide specific error messages
        error_msg = str(e)
        if "429" in error_msg or "rate limit" in error_msg.lower():
            raise ValueError("API rate limit exceeded. Please wait a few minutes before trying again.")
        elif "timeout" in error_msg.lower():
            raise ValueError("Request timed out. Please try again with fewer questions or smaller materials.")
        elif "connection" in error_msg.lower():
            raise ValueError("Connection error. Please check your internet and try again.")
        else:
            raise ValueError(f"Failed to generate questions: {str(e)}")

# ============================================
# HELPER FUNCTIONS FOR AI SERVICE
# ============================================

def get_open_ended_type_for_bloom(bloom_level: str) -> str:
    """Map Bloom's taxonomy level to appropriate open-ended question type"""
    mapping = {
        'remember': 'short_answer',
        'understand': 'explanation',
        'apply': 'problem_solving',
        'analyze': 'description',
        'evaluate': 'explanation',
        'create': 'discussion'
    }
    return mapping.get(bloom_level, 'short_answer')


def build_variation_prompt(variation_mode: str) -> str:
    """Build variation-specific guidance for AI prompt"""
    
    if variation_mode == 'high':
        return """VARIATION STRATEGY (High Diversity):
For questions on the same topic:
- Vary question structure (direct vs. scenario-based)
- Use different key terms and contexts
- Mix question types and approaches
- Ensure unique phrasing for each question
EXAMPLE: Instead of "Define X" and "What is X?", ask "How does X apply to Y?" and "Compare X and Z"."""
    
    elif variation_mode == 'focused':
        return """VARIATION STRATEGY (Focused):
- Questions closely tied to specific material passages
- Use consistent terminology from source materials
- Direct connection to provided content
- Minimal reformulation or variation
EXAMPLE: Quote or closely paraphrase material when forming questions."""
    
    else:
        return """VARIATION STRATEGY (Standard):
- Mix direct and reformulated questions
- Natural variation in phrasing
- Balance between recall and synthesis
- Diverse but coherent question set
EXAMPLE: Mix "What is X?", "How does X relate to Y?", and "Apply X to scenario Z"."""


def get_similarity_description(similarity: int) -> str:
    """Get description for similarity percentage"""
    if similarity <= 20:
        return "Highly original - minimal material copying"
    elif similarity <= 40:
        return "Moderate originality - good balance"
    elif similarity <= 60:
        return "Material-focused - questions use content context"
    elif similarity <= 80:
        return "Content-aligned - questions closely match materials"
    else:
        return "Maximum alignment - direct material usage acceptable"


def get_variation_description(mode: str) -> str:
    """Get description for variation mode"""
    modes = {
        'standard': 'Mix question types and approaches naturally',
        'high': 'Maximize variation in phrasing and structure',
        'focused': 'Align closely with provided material'
    }
    return modes.get(mode, 'Standard mode applied')


def format_clo_distribution(clo_dist):
    """Format CLO distribution"""
    if not clo_dist:
        return "Distribute evenly across all CLOs"
    return "\n".join([f"- {clo}: {count} question(s)" for clo, count in clo_dist.items()])


def format_bloom_distribution(bloom_dist):
    """Format Bloom distribution"""
    if not bloom_dist:
        return "Distribute evenly across Bloom levels"
    return "\n".join([f"- {level.capitalize()}: {count} question(s)" for level, count in bloom_dist.items()])


def format_difficulty_distribution(diff_dist):
    """Format difficulty distribution"""
    if not diff_dist:
        return "Distribute evenly: 33% easy, 34% medium, 33% hard"
    return "\n".join([f"- {level.capitalize()}: {count} question(s)" for level, count in diff_dist.items()])


def calculate_question_distribution(num_questions, clo_dist, bloom_dist, difficulty_dist):
    """Calculate exact distribution per attribute"""
    distribution = {'clo': {}, 'bloom': {}, 'difficulty': {}}
    
    # CLO distribution
    for clo, percentage in clo_dist.items():
        count = round((percentage / 100) * num_questions)
        distribution['clo'][clo] = count
    
    if distribution['clo']:
        clo_total = sum(distribution['clo'].values())
        if clo_total != num_questions:
            max_clo = max(distribution['clo'], key=distribution['clo'].get)
            distribution['clo'][max_clo] += (num_questions - clo_total)
    
    # Bloom distribution
    for level, percentage in bloom_dist.items():
        count = round((percentage / 100) * num_questions)
        distribution['bloom'][level] = count
    
    if distribution['bloom']:
        bloom_total = sum(distribution['bloom'].values())
        if bloom_total != num_questions:
            max_bloom = max(distribution['bloom'], key=distribution['bloom'].get)
            distribution['bloom'][max_bloom] += (num_questions - bloom_total)
    
    # Difficulty distribution
    for level, percentage in difficulty_dist.items():
        count = round((percentage / 100) * num_questions)
        distribution['difficulty'][level] = count
    
    if distribution['difficulty']:
        diff_total = sum(distribution['difficulty'].values())
        if diff_total != num_questions:
            max_diff = max(distribution['difficulty'], key=distribution['difficulty'].get)
            distribution['difficulty'][max_diff] += (num_questions - diff_total)
    
    return distribution


def format_clo_number(clo_str):
    """Ensure CLO is formatted as 'CLO 1', 'CLO 2', etc."""
    if not clo_str or clo_str == 'N/A':
        return 'CLO 1'
    
    match = re.search(r'(\d+)', str(clo_str))
    if match:
        num = match.group(1)
        return f'CLO {num}'
    
    return str(clo_str)


def extract_key_concepts(text: str) -> list:
    """
    Extract key concepts and terms from text for better context.
    Helps AI understand what's important in the material.
    """
    lines = [l.strip() for l in text.split('\n') if l.strip() and len(l.strip()) > 10]
    
    concepts = []
    for line in lines[:20]:
        if any(keyword in line.lower() for keyword in ['is defined as', 'means', 'refers to', 'represents']):
            parts = line.split(':')
            if len(parts) > 1:
                concept = parts[0].strip()
                if len(concept) < 50:
                    concepts.append(concept)
    
    for line in lines:
        words = re.findall(r'\b[A-Z]{3,}\b', line)
        concepts.extend(words)
    
    return list(set(concepts))[:10]


def generate_summary(file_path=None, file_type=None, text_content=None):
    """Generate a summary of document content using Groq API"""
    api_key = current_app.config['GROQ_API_KEY']

    if not api_key:
        raise ValueError("Groq API key is not configured")
   
    model = current_app.config.get('GROQ_LLAMA_MODEL')
   
    if file_path and not text_content:
        from app.services.file_service import get_file_path, extract_text_from_file
        full_path = get_file_path(file_path)
        text_content = extract_text_from_file(full_path)
   
    if not text_content:
        raise ValueError("No content available to summarize")
   
    prompt = f"""Provide a concise summary (200-300 words) of the following educational content. 
Focus on key concepts, learning objectives, and important relationships.

CONTENT:
{text_content[:5000]}

SUMMARY:"""
   
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
   
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are an educational assistant that creates clear, focused summaries."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3,
        "max_tokens": 1000
    }
   
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data['choices'][0]['message']['content'].strip()
    except requests.exceptions.RequestException as e:
        current_app.logger.error(f"Error calling Groq API: {str(e)}")
        raise ValueError(f"Error generating summary: {str(e)}")


def get_ai_response(user_message, document_summary, chat_history=None):
    """Get AI response for chat-based Q&A"""
    api_key = current_app.config['GROQ_API_KEY']

    if not api_key:
        raise ValueError("Groq API key is not configured")
   
    model = current_app.config.get('GROQ_LLAMA_MODEL')
   
    messages = [
        {
            "role": "system",
            "content": f"""You are an educational assistant helping students learn from course materials.
Answer questions based on the provided document summary. Be accurate and specific.
Document Summary: {document_summary}"""
        }
    ]
   
    if chat_history:
        for msg in chat_history:
            role = "user" if msg.is_user else "assistant"
            messages.append({"role": role, "content": msg.content})
   
    messages.append({"role": "user", "content": user_message})
   
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
   
    payload = {
        "model": model,
        "messages": messages,
        "temperature": 0.7,
        "max_tokens": 1000
    }
   
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()
        data = response.json()
        return data['choices'][0]['message']['content'].strip()
    except requests.exceptions.RequestException as e:
        current_app.logger.error(f"Error calling Groq API: {str(e)}")
        raise ValueError(f"Error generating response: {str(e)}")


def generate_quiz_feedback(questions, score, document_summary):
    """
    Generate personalized feedback based on quiz performance
   
    Args:
        questions (list): List of QuizQuestion objects or dicts (for week quizzes)
        score (float): Quiz score percentage
        document_summary (str): Summary of the document or week content
       
    Returns:
        str: Personalized feedback
    """
    api_key = current_app.config['GROQ_API_KEY']

    if not api_key:
        raise ValueError("Groq API key is not configured")
   
    model = current_app.config.get('GROQ_LLAMA_MODEL')
   
    # Prepare information about incorrect answers (handles both QuizQuestion objects and dicts)
    incorrect_questions = []
    correct_questions = []
   
    for q in questions:
        if hasattr(q, 'is_correct'):  # QuizQuestion object
            is_correct = q.is_correct
            student_choice = q.student_choice
            correct_choice = q.correct_choice
            choice_a = q.choice_a
            choice_b = q.choice_b
            choice_c = q.choice_c
            explanation = q.explanation
            question_text = q.question_text
        else:  # Dict (for week quizzes)
            is_correct = (q.get('student_choice') == q.get('correct_choice'))
            student_choice = q.get('student_choice')
            correct_choice = q.get('correct_choice')
            choice_a = q.get('choice_a')
            choice_b = q.get('choice_b')
            choice_c = q.get('choice_c')
            explanation = q.get('explanation')
            question_text = q.get('question')
       
        if is_correct:
            correct_questions.append(q)
        else:
            incorrect_questions.append({
                "question": question_text,
                "student_choice": student_choice,
                "correct_choice": correct_choice,
                "choice_a": choice_a,
                "choice_b": choice_b,
                "choice_c": choice_c,
                "explanation": explanation
            })
   
    # Prepare the prompt
    prompt = f"""
    Generate personalized feedback for a student who completed a multiple-choice quiz on the following topic:
   
    Document Summary:
    {document_summary}
   
    Quiz Performance:
    - Score: {score:.1f}%
    - {len(correct_questions)} correct answers out of {len(questions)} questions
   
    Incorrect Answers:
    {json.dumps(incorrect_questions, indent=2)}
   
    Please provide:
    1. An overall assessment of their performance
    2. Specific feedback on areas they should focus on based on their incorrect answers
    3. Recommendations for improvement
    4. Encouragement and positive reinforcement
   
    The feedback should be constructive, specific to their mistakes, and reference the content they were tested on.
    The feedback should be in the same language as the Document Summary.
    """
   
    # Call Groq API
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
   
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are an educational assistant that provides personalized and constructive feedback on quiz performance."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.7,
        "max_tokens": 1000
    }
   
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()  # Raise exception for HTTP errors
       
        data = response.json()
        feedback = data['choices'][0]['message']['content'].strip()
       
        return feedback
    except Exception as e:
        current_app.logger.error(f"Error generating quiz feedback: {str(e)}")
        raise ValueError(f"Error generating quiz feedback: {str(e)}")    


def evaluate_quiz_answer(student_answer, correct_answer, question_text):
    """
    Evaluate if a student's answer is correct using AI
   
    Args:
        student_answer (str): The student's response
        correct_answer (str): The correct answer
        question_text (str): The question being asked
       
    Returns:
        bool: Whether the answer is correct
        str: Feedback on the answer (optional)
    """
    api_key = current_app.config['GROQ_API_KEY']

    if not api_key:
        raise ValueError("Groq API key is not configured")
   
    model = current_app.config.get('GROQ_LLAMA_MODEL')
   
    # Prepare the prompt
    prompt = f"""
    Please evaluate the student's answer to the following question:
   
    Question: {question_text}
   
    Correct answer: {correct_answer}
   
    Student's answer: {student_answer}
   
    Is the student's answer conceptually correct? Consider the meaning rather than exact wording.
    The answer is correct if it demonstrates understanding of the core concept, even if it doesn't
    match the expected answer word-for-word. Spelling mistakes, grammatical errors, and
    slightly different phrasing should be tolerated if the main point is correct.
    The evaluation should be in the same language as the student answer.

    Respond in JSON format with two fields:
    1. "is_correct": true or false
    2. "feedback": brief specific feedback on the answer (what was good or what was missing)
   
    Example response:
    {{
        "is_correct": true,
        "feedback": "Your answer correctly identifies the main concept but could be more specific about X."
    }}
    """
   
    # Call Groq API
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
   
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are an educational assistant that evaluates student answers fairly and constructively."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3,
        "max_tokens": 500,
        "response_format": {"type": "json_object"}
    }
   
    try:
        response = requests.post(url, headers=headers, json=payload)
        response.raise_for_status()  # Raise exception for HTTP errors
       
        data = response.json()
        content = data['choices'][0]['message']['content']
       
        # Parse the JSON response
        result = json.loads(content)
       
        return result.get('is_correct', False), result.get('feedback', '')
    except Exception as e:
        current_app.logger.error(f"Error evaluating answer: {str(e)}")
        # Fall back to simple string matching if the API call fails
        is_correct = student_answer.lower().strip() == correct_answer.lower().strip()
        return is_correct, "Unable to generate detailed feedback."


# ============================================
# ACTIVITY PATTERN EXTRACTION & SCORING
# ============================================

def extract_activity_patterns(activity_text: str, clo_data: list, course_id: int) -> dict:
    """
    Extract patterns from activity file for quiz alignment.
    Uses existing functions to classify questions and extract metadata.
    
    Args:
        activity_text: Raw text from activity file
        clo_data: List of CLO dicts with 'CLO#' and 'CLO Description'
        course_id: Course ID for context
        
    Returns:
        Dict with clo_distribution, bloom_distribution, keywords_pool, questions_count
    """
    current_app.logger.info(f"🎯 Extracting activity patterns from {len(activity_text)} chars")
    
    try:
        # Step 1: Extract questions from activity text
        questions_raw = extract_questions_from_text(activity_text)
        questions = [normalize_question_keys(q) for q in questions_raw]
        
        current_app.logger.info(f"✓ Extracted {len(questions)} questions from activity")
        
        if len(questions) < 2:
            current_app.logger.warning("⚠️  Activity has too few questions for pattern analysis")
            return {
                'questions_count': 0,
                'clo_distribution': {},
                'bloom_distribution': {},
                'keywords_pool': {}
            }
        
        # Step 2: Classify by CLO
        clo_classified_raw = classify_questions_clo(questions, clo_data)
        
        # IMPORTANT: Normalize keys after CLO classification
        clo_classified = [normalize_question_keys(q) for q in clo_classified_raw]
        
        # Step 3: Classify by Bloom
        bloom_classified = classify_questions_bloom(clo_classified)
        
        current_app.logger.info(f"✓ Classified {len(bloom_classified)} questions")
        
        # Step 4: Calculate CLO distribution
        clo_counts = {}
        for q in bloom_classified:
            clos = q.get("CLO#")
            if isinstance(clos, list):
                for c in clos:
                    clo_counts[c] = clo_counts.get(c, 0) + 1
            elif clos:
                clo_counts[clos] = clo_counts.get(clos, 0) + 1
        
        total_q = len(bloom_classified)
        clo_distribution = {str(k): round((v / total_q) * 100, 1) for k, v in clo_counts.items()}
        
        # Step 5: Calculate Bloom distribution
        bloom_counts = {
            'remember': 0, 'understand': 0, 'apply': 0,
            'analyze': 0, 'evaluate': 0, 'create': 0
        }
        for q in bloom_classified:
            level = q.get("Bloom_Level", "understand").lower()
            if level in bloom_counts:
                bloom_counts[level] += 1
        
        bloom_distribution = {k: round((v / total_q) * 100, 1) if total_q > 0 else 0 
                             for k, v in bloom_counts.items()}
        
        # Step 6: Extract keywords pool from questions
        keywords_pool = {}
        for q in bloom_classified:
            text = q.get('Text', '').lower()
            # Extract key terms (3+ chars, not common words)
            terms = re.findall(r'\b[a-zA-Z]{3,}\b', text)
            for term in terms:
                if term not in ['the', 'and', 'for', 'are', 'you', 'with', 'from']:
                    keywords_pool[term] = keywords_pool.get(term, 0) + 1
        
        # Keep top 30 keywords by frequency
        top_keywords = dict(sorted(keywords_pool.items(), 
                                   key=lambda x: x[1], 
                                   reverse=True)[:30])
        
        result = {
            'questions_count': len(bloom_classified),
            'clo_distribution': clo_distribution,
            'bloom_distribution': bloom_distribution,
            'keywords_pool': top_keywords
        }
        
        current_app.logger.info(f"✓ Activity patterns: {len(bloom_classified)} Q, "
                               f"{len(clo_distribution)} CLOs, {len(top_keywords)} keywords")
        
        return result
        
    except Exception as e:
        current_app.logger.error(f"❌ Failed to extract activity patterns: {str(e)}")
        import traceback
        current_app.logger.error(traceback.format_exc())
        
        return {
            'questions_count': 0,
            'clo_distribution': {},
            'bloom_distribution': {},
            'keywords_pool': {}
        }


def score_question_activity_alignment(
    question: dict, 
    activity_patterns: dict
) -> tuple:
    """
    Score how well a question aligns with activity patterns.
    Uses STRUCTURAL matching (types, Bloom levels, CLOs) NOT keywords.
    
    Args:
        question: Generated question dict with clo, bloom_level, question_type
        activity_patterns: Dict from extract_activity_patterns()
        
    Returns:
        (is_activity_inspired: bool, alignment_score: float, alignment_details: str)
    """
    if not activity_patterns or not activity_patterns.get('questions_count'):
        return False, 0.0, "No activity file"
    
    alignment_points = 0
    total_checks = 4
    details = []
    
    # ============================================
    # Check 1: Question Type Match
    # ============================================
    q_type = question.get('question_type', 'mcq').lower()
    
    if q_type == 'mcq' or not q_type:
        activity_qtype = 'mcq'
    else:
        activity_qtype = 'open_ended'
    
    activity_types = activity_patterns.get('question_types', {})
    
    # Does activity have this type of question?
    if activity_qtype == 'mcq' and activity_types.get('mcq', 0) > 0:
        alignment_points += 1
        details.append("✓ Question type matches activity (MCQ)")
    elif activity_qtype == 'open_ended' and sum(activity_types.get(k, 0) for k in ['short_answer', 'essay', 'problem_solving']) > 0:
        alignment_points += 1
        details.append("✓ Question type matches activity (Open-Ended)")
    else:
        details.append("✗ Question type not prevalent in activity")
    
    # ============================================
    # Check 2: Bloom Level Match
    # ============================================
    q_bloom = question.get('bloom_level', 'understand').lower()
    activity_bloom = activity_patterns.get('bloom_distribution', {})
    
    if q_bloom in activity_bloom and activity_bloom[q_bloom] > 0:
        alignment_points += 1
        details.append(f"✓ Bloom level '{q_bloom}' is used in activity ({activity_bloom[q_bloom]:.0f}%)")
    else:
        details.append(f"✗ Bloom level '{q_bloom}' not common in activity")
    
    # ============================================
    # Check 3: CLO Match
    # ============================================
    q_clo = str(question.get('clo', 'CLO 1')).strip()
    activity_clos = activity_patterns.get('clo_distribution', {})
    
    # Check if this CLO is tested in activity
    clo_match = False
    for activity_clo in activity_clos.keys():
        if str(activity_clo) in q_clo or q_clo in str(activity_clo):
            clo_match = True
            details.append(f"✓ CLO '{q_clo}' is covered in activity")
            break
    
    if clo_match:
        alignment_points += 1
    else:
        details.append(f"✗ CLO '{q_clo}' not emphasized in activity")
    
    # ============================================
    # Check 4: Question Distribution Match
    # ============================================
    total_activity_q = activity_patterns.get('questions_count', 0)
    if total_activity_q > 0:
        activity_mcq_pct = (activity_patterns.get('total_mcq_in_activity', 0) / total_activity_q) * 100
        activity_open_pct = (activity_patterns.get('total_open_in_activity', 0) / total_activity_q) * 100
        
        # If activity is mostly MCQ, give points for MCQ questions
        if activity_mcq_pct > 60 and q_type in ['mcq', None]:
            alignment_points += 1
            details.append(f"✓ Activity is {activity_mcq_pct:.0f}% MCQ; this is MCQ")
        # If activity is mostly open-ended, give points for open-ended
        elif activity_open_pct > 60 and q_type == 'open_ended':
            alignment_points += 1
            details.append(f"✓ Activity is {activity_open_pct:.0f}% open-ended; this is open-ended")
        else:
            details.append("≈ Question type distribution reasonable")
            alignment_points += 0.5
    
    # ============================================
    # Calculate Final Alignment Score
    # ============================================
    alignment_score = (alignment_points / total_checks) * 100
    is_activity_inspired = alignment_score >= 50  # Threshold: >50% alignment
    
    alignment_summary = "; ".join(details)
    
    return is_activity_inspired, round(alignment_score, 1), alignment_summary


def score_chunk_by_activity_patterns(chunk_text: str, activity_patterns: dict) -> float:
    """
    Score how well a chunk matches activity patterns (0-1).
    Used by RAG service for weighted retrieval.
    
    Args:
        chunk_text: Text chunk to score
        activity_patterns: Dict from extract_activity_patterns()
        
    Returns:
        Similarity score (0.0-1.0)
    """
    if not activity_patterns or not activity_patterns.get('keywords_pool'):
        return 0.0
    
    keywords_pool = activity_patterns['keywords_pool']
    chunk_lower = chunk_text.lower()
    keyword_matches = 0
    
    for keyword in keywords_pool.keys():
        if keyword in chunk_lower:
            keyword_matches += 1
    
    score = keyword_matches / len(keywords_pool) if keywords_pool else 0.0
    return min(score, 1.0)


def verify_activity_integration(generated_questions: list, activity_patterns: dict) -> dict:
    """
    Verify that generated quiz aligns with activity patterns.
    Returns alignment report with metrics.
    
    Args:
        generated_questions: List of question dicts from generate_quiz_questions()
        activity_patterns: Dict from extract_activity_patterns()
        
    Returns:
        Dict with alignment metrics and report
    """
    if not activity_patterns or not activity_patterns.get('questions_count'):
        return {
            'activity_used': False,
            'message': 'No activity file was used for alignment.',
            'clo_alignment_percent': 0,
            'bloom_alignment_percent': 0,
            'keyword_matches': 0
        }
    
    try:
        # Extract CLOs from generated questions
        generated_clos = {}
        for q in generated_questions:
            clo = q.get('clo', 'CLO 1')
            generated_clos[clo] = generated_clos.get(clo, 0) + 1
        
        # Compare with activity CLO distribution
        activity_clos = activity_patterns.get('clo_distribution', {})
        clo_matches = 0
        for clo in generated_clos:
            if any(str(clo) in str(k) or str(k) in str(clo) for k in activity_clos.keys()):
                clo_matches += 1
        
        total_clos = max(len(generated_clos), len(activity_clos)) or 1
        clo_alignment = round((clo_matches / total_clos) * 100)
        
        # Extract Bloom levels from generated questions
        generated_bloom = {}
        for q in generated_questions:
            bloom = q.get('bloom_level', 'understand')
            generated_bloom[bloom] = generated_bloom.get(bloom, 0) + 1
        
        # Compare with activity Bloom distribution
        activity_bloom = activity_patterns.get('bloom_distribution', {})
        bloom_matches = 0
        for bloom in generated_bloom:
            if bloom in activity_bloom:
                bloom_matches += 1
        
        total_bloom = max(len(generated_bloom), len(activity_bloom)) or 1
        bloom_alignment = round((bloom_matches / total_bloom) * 100)
        
        # Count keyword matches in generated questions
        keywords_pool = activity_patterns.get('keywords_pool', {})
        keyword_count = 0
        
        full_text = ' '.join([q.get('question', '') + ' ' + 
                             q.get('explanation', '') 
                             for q in generated_questions]).lower()
        
        for keyword in keywords_pool.keys():
            if keyword in full_text:
                keyword_count += 1
        
        message = (f"✓ Quiz aligned with activity file: "
                  f"{clo_alignment}% CLO match, "
                  f"{bloom_alignment}% Bloom match, "
                  f"{keyword_count}/{len(keywords_pool)} keywords covered")
        
        current_app.logger.info(f"📊 Activity alignment: CLO {clo_alignment}%, "
                               f"Bloom {bloom_alignment}%, Keywords {keyword_count}")
        
        return {
            'activity_used': True,
            'message': message,
            'clo_alignment_percent': clo_alignment,
            'bloom_alignment_percent': bloom_alignment,
            'keyword_matches': keyword_count
        }
        
    except Exception as e:
        current_app.logger.error(f"❌ Failed to verify alignment: {str(e)}")
        return {
            'activity_used': True,
            'message': f'Alignment verification incomplete: {str(e)}',
            'clo_alignment_percent': 0,
            'bloom_alignment_percent': 0,
            'keyword_matches': 0
        }

# ============================================
# IMPROVED EVALUATION FUNCTIONS
# ============================================

def evaluate_quiz_answer_enhanced(
    student_answer: str,
    model_answer: str,
    question_text: str,
    bloom_level: str = 'understand',
    evaluation_criteria: list = None,
    grading_rubric: str = None
) -> dict:
    """
    Enhanced evaluation of student answers with detailed assessment.
    
    Args:
        student_answer (str): The student's response
        model_answer (str): The expected/model answer
        question_text (str): The question being asked
        bloom_level (str): Bloom's taxonomy level (remember, understand, apply, etc.)
        evaluation_criteria (list): Specific criteria to evaluate
        grading_rubric (str): Custom grading guidance
        
    Returns:
        dict with:
            - is_correct (bool): Overall correctness
            - score (float): Score 0-100
            - feedback (str): Detailed feedback
            - strengths (list): What was done well
            - areas_for_improvement (list): What could be better
            - detailed_assessment (str): Full assessment
    """
    api_key = current_app.config['GROQ_API_KEY']
    if not api_key:
        raise ValueError("Groq API key is not configured")
    
    model = current_app.config.get('GROQ_LLAMA_MODEL')
    
    # Build evaluation criteria string
    criteria_str = ""
    if evaluation_criteria:
        criteria_str = "Evaluation Criteria:\n" + "\n".join([f"- {c}" for c in evaluation_criteria])
    
    rubric_str = ""
    if grading_rubric:
        rubric_str = f"\nGrading Rubric:\n{grading_rubric}"
    
    # Build comprehensive prompt
    prompt = f"""
Evaluate the student's answer comprehensively and fairly.

QUESTION:
{question_text}

BLOOM'S LEVEL: {bloom_level.upper()}

MODEL ANSWER:
{model_answer}

STUDENT'S ANSWER:
{student_answer}

{criteria_str}
{rubric_str}

EVALUATION GUIDELINES:
1. Assess CONCEPTUAL UNDERSTANDING, not just exact wording
2. Consider:
   - Accuracy of core concepts
   - Completeness of response
   - Clarity of explanation
   - Use of appropriate terminology
   - Supporting details or examples
   - Understanding depth appropriate to Bloom's level

3. Scoring:
   - 90-100: Excellent (complete, accurate, well-explained)
   - 75-89: Good (mostly correct with minor gaps)
   - 60-74: Fair (correct core concepts but incomplete)
   - 40-59: Poor (significant gaps in understanding)
   - 0-39: Failing (major misunderstandings)

4. Be CONSTRUCTIVE and ENCOURAGING

Respond ONLY in valid JSON format:
{{
    "is_correct": true/false,
    "score": 0-100,
    "feedback": "brief overall feedback",
    "strengths": ["strength 1", "strength 2"],
    "areas_for_improvement": ["area 1", "area 2"],
    "detailed_assessment": "detailed explanation of the assessment",
    "model_answer_comparison": "how the student answer compares to model answer"
}}
"""
    
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": """You are an expert educational evaluator that assesses student answers fairly and constructively.
You understand different Bloom's taxonomy levels and adjust evaluation rigor accordingly.
You provide specific, actionable feedback."""
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3,
        "max_tokens": 1000,
        "response_format": {"type": "json_object"}
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        content = data['choices'][0]['message']['content']
        
        # Parse the JSON response
        result = json.loads(content)
        
        current_app.logger.info(f"✓ Enhanced evaluation: Score {result.get('score', 0)}/100")
        
        return {
            'is_correct': result.get('is_correct', False),
            'score': result.get('score', 0),
            'feedback': result.get('feedback', ''),
            'strengths': result.get('strengths', []),
            'areas_for_improvement': result.get('areas_for_improvement', []),
            'detailed_assessment': result.get('detailed_assessment', ''),
            'model_answer_comparison': result.get('model_answer_comparison', '')
        }
        
    except Exception as e:
        current_app.logger.error(f"Error in enhanced evaluation: {str(e)}")
        # Fallback to simple evaluation
        return simple_evaluate_answer(student_answer, model_answer, question_text)


def simple_evaluate_answer(student_answer: str, model_answer: str, question_text: str) -> dict:
    """
    Simple fallback evaluation using basic similarity metrics.
    Used when AI evaluation fails.
    
    Args:
        student_answer (str): Student response
        model_answer (str): Expected answer
        question_text (str): Question
        
    Returns:
        dict with basic evaluation
    """
    # Calculate basic similarity
    student_lower = student_answer.lower().strip()
    model_lower = model_answer.lower().strip()
    
    # Simple metrics
    exact_match = student_lower == model_lower
    contains_key_words = sum(1 for word in model_lower.split() 
                            if len(word) > 3 and word in student_lower) / max(len([w for w in model_lower.split() if len(w) > 3]), 1)
    
    # Calculate score
    if exact_match:
        score = 100
        is_correct = True
    elif contains_key_words > 0.7:
        score = 80
        is_correct = True
    elif contains_key_words > 0.5:
        score = 60
        is_correct = False
    else:
        score = 30
        is_correct = False
    
    return {
        'is_correct': is_correct,
        'score': score,
        'feedback': f"Answer scored {score}/100 based on key concept coverage.",
        'strengths': ["Response was provided"] if student_answer.strip() else [],
        'areas_for_improvement': ["Consider including more details from the model answer"],
        'detailed_assessment': f"Basic comparison shows {contains_key_words*100:.0f}% key concept coverage.",
        'model_answer_comparison': "See model answer for complete reference."
    }


def evaluate_open_ended_with_context(
    student_answer: str,
    question: dict,
    course_context: str = None
) -> dict:
    """
    Evaluate an open-ended answer with full context.
    
    Args:
        student_answer (str): Student's response
        question (dict): Question data with model_answer, evaluation_criteria, grading_rubric, bloom_level
        course_context (str): Additional course/material context
        
    Returns:
        dict with comprehensive evaluation
    """
    try:
        evaluation = evaluate_quiz_answer_enhanced(
            student_answer=student_answer,
            model_answer=question.get('model_answer', ''),
            question_text=question.get('question', ''),
            bloom_level=question.get('bloom_level', 'understand'),
            evaluation_criteria=question.get('evaluation_criteria', []),
            grading_rubric=question.get('grading_rubric', '')
        )
        
        return evaluation
        
    except Exception as e:
        current_app.logger.error(f"Error in context-based evaluation: {str(e)}")
        return simple_evaluate_answer(
            student_answer,
            question.get('model_answer', ''),
            question.get('question', '')
        )


def batch_evaluate_open_ended(questions_with_answers: list) -> list:
    """
    Evaluate multiple open-ended answers efficiently.
    
    Args:
        questions_with_answers (list): List of dicts with:
            - question (str)
            - student_answer (str)
            - model_answer (str)
            - bloom_level (str)
            - evaluation_criteria (list)
            - grading_rubric (str)
        
    Returns:
        list of evaluation results
    """
    results = []
    
    for item in questions_with_answers:
        try:
            result = evaluate_quiz_answer_enhanced(
                student_answer=item.get('student_answer', ''),
                model_answer=item.get('model_answer', ''),
                question_text=item.get('question', ''),
                bloom_level=item.get('bloom_level', 'understand'),
                evaluation_criteria=item.get('evaluation_criteria', []),
                grading_rubric=item.get('grading_rubric', '')
            )
            result['question_id'] = item.get('question_id', '')
            results.append(result)
            
        except Exception as e:
            current_app.logger.warning(f"Skipping evaluation due to error: {str(e)}")
            results.append({
                'question_id': item.get('question_id', ''),
                'is_correct': None,
                'score': 0,
                'feedback': 'Evaluation pending',
                'error': str(e)
            })
    
    return results


def generate_detailed_model_answer(
    question_text: str,
    clo: str,
    bloom_level: str,
    course_context: str,
    source_material: str
) -> str:
    """
    Generate a comprehensive model answer for an open-ended question.
    
    Args:
        question_text (str): The question
        clo (str): Related CLO
        bloom_level (str): Bloom's taxonomy level
        course_context (str): Course context/objectives
        source_material (str): Relevant course material
        
    Returns:
        str: Detailed model answer
    """
    api_key = current_app.config['GROQ_API_KEY']
    if not api_key:
        raise ValueError("Groq API key is not configured")
    
    model = current_app.config.get('GROQ_LLAMA_MODEL')
    
    prompt = f"""
Generate a comprehensive model answer for this open-ended question.

QUESTION:
{question_text}

RELATED CLO:
{clo}

BLOOM'S LEVEL: {bloom_level.upper()}

COURSE CONTEXT:
{course_context}

RELEVANT MATERIAL:
{source_material[:2000]}

REQUIREMENTS:
1. Appropriate depth for Bloom's level: {bloom_level}
2. Address the CLO: {clo}
3. Use course terminology
4. Include specific examples from materials if relevant
5. Be clear and well-structured
6. Include key concepts that must appear in student answers

Generate the model answer:
"""
    
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "You are an expert educator creating comprehensive model answers for open-ended questions."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.5,
        "max_tokens": 800
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        model_answer = data['choices'][0]['message']['content'].strip()
        
        return model_answer
        
    except Exception as e:
        current_app.logger.error(f"Error generating model answer: {str(e)}")
        raise ValueError(f"Failed to generate model answer: {str(e)}")


def create_evaluation_criteria_for_question(
    question_text: str,
    bloom_level: str,
    clo: str
) -> dict:
    """
    Auto-generate evaluation criteria for an open-ended question.
    
    Args:
        question_text (str): The question
        bloom_level (str): Bloom's level
        clo (str): Related CLO
        
    Returns:
        dict with:
            - criteria (list): Evaluation criteria
            - rubric (str): Grading rubric
            - key_concepts (list): Key concepts to include
    """
    api_key = current_app.config['GROQ_API_KEY']
    if not api_key:
        raise ValueError("Groq API key is not configured")
    
    model = current_app.config.get('GROQ_LLAMA_MODEL')
    
    prompt = f"""
Create evaluation criteria for this open-ended question.

QUESTION:
{question_text}

BLOOM'S LEVEL: {bloom_level.upper()}
CLO: {clo}

Generate in JSON format:
{{
    "criteria": [
        "criterion 1",
        "criterion 2",
        "criterion 3"
    ],
    "rubric": "How to grade (brief)",
    "key_concepts": ["concept1", "concept2", "concept3"]
}}
"""
    
    url = "https://api.groq.com/openai/v1/chat/completions"
    headers = {
        "Authorization": f"Bearer {api_key}",
        "Content-Type": "application/json"
    }
    
    payload = {
        "model": model,
        "messages": [
            {
                "role": "system",
                "content": "Generate evaluation criteria for open-ended questions."
            },
            {
                "role": "user",
                "content": prompt
            }
        ],
        "temperature": 0.3,
        "max_tokens": 500,
        "response_format": {"type": "json_object"}
    }
    
    try:
        response = requests.post(url, headers=headers, json=payload, timeout=30)
        response.raise_for_status()
        
        data = response.json()
        content = data['choices'][0]['message']['content']
        result = json.loads(content)
        
        return result
        
    except Exception as e:
        current_app.logger.error(f"Error creating criteria: {str(e)}")
        return {
            'criteria': ['Demonstrates understanding of core concepts', 'Clear explanation', 'Proper terminology'],
            'rubric': 'Score based on completeness and accuracy',
            'key_concepts': []
        }
    
