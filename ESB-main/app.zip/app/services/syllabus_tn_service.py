import os
import json
import pdfplumber
import docx
import markdownify
import logging
from flask import current_app
from groq import Groq

# OCR
import pytesseract
from PIL import Image

logger = logging.getLogger(__name__)

pytesseract.pytesseract.tesseract_cmd = r"C:/Program Files/Tesseract-OCR/tesseract.exe"


# ---------------------------------------------------------
# CLEAN HELPERS
# ---------------------------------------------------------
def clean_utf(text):
    if not isinstance(text, str):
        return text
    try:
        return text.encode("latin1", "ignore").decode("utf8", "ignore")
    except:
        return text


def clean_json(x):
    if isinstance(x, dict):
        return {k: clean_json(v) for k, v in x.items()}
    if isinstance(x, list):
        return [clean_json(v) for v in x]
    if isinstance(x, str):
        return clean_utf(x)
    return x


# ---------------------------------------------------------
# AAP DETECTOR WITH OCR (WORKS WITH ESB PDF)
# ---------------------------------------------------------
import base64
import pdfplumber
import io
from groq import Groq
from flask import current_app

def extract_aap_from_pdf(pdf_path):
    """
    Automatically detects the AAP table by finding the text 'AAP' and cropping around it.
    Then uses Groq Vision to detect X marks.
    """
    try:
        with pdfplumber.open(pdf_path) as pdf:

            if len(pdf.pages) < 3:
                return []

            page = pdf.pages[2]

            # --- Extract all text positions ---
            words = page.extract_words()

            # Find the "AAP" header row
            aap_words = [w for w in words if w["text"].startswith("AAP")]

            if not aap_words:
                print("No AAP header found.")
                return []

            # Take the first AAP word position
            aap = aap_words[0]

            x0 = aap["x0"] - 20     # expand a bit left
            top = aap["top"] - 40   # go higher
            x1 = page.width - 20
            bottom = aap["top"] + 180  # go lower

            bbox = (x0, top, x1, bottom)
            cropped = page.crop(bbox)

            # Save debug crop
            img = cropped.to_image(resolution=250).original
            img.save("debug_aap_crop.png")

            # Convert to base64
            buf = io.BytesIO()
            img.save(buf, format="PNG")
            b64_img = base64.b64encode(buf.getvalue()).decode()

        # ---- CALL GROQ VISION MODEL ----
        api_key = current_app.config.get("GROQ_API_KEY")
        client = Groq(api_key=api_key)

        prompt = """
You will see a table row with AAP numbers (1–12). 
Some boxes contain an X. Identify only which AAP numbers contain an X.

Respond ONLY as JSON inside <json></json>:

<json>
[
  {"AAP#": 7, "selected": true},
  {"AAP#": 8, "selected": true}
]
</json>
"""

        response = client.chat.completions.create(
            model="meta-llama/llama-4-scout-17b-16e-instruct",
            messages=[
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {
                            "type": "image_url",
                            "image_url": {"url": f"data:image/png;base64,{b64_img}"}
                        }
                    ]
                }
            ],
            temperature=0
        )

        content = response.choices[0].message.content

        if "<json>" not in content:
            return []

        json_block = content.split("<json>")[1].split("</json>")[0].strip()
        return json.loads(json_block)

    except Exception as e:
        logger.error(f"AAP Vision LLM error: {e}")
        return []

import re

def _extract_json_block(tagged_text: str, tag: str = "json") -> str:
    """
    Extract content inside <json> ... </json>
    """
    if not tagged_text:
        raise ValueError("Empty LLM response")

    start = tagged_text.find(f"<{tag}>")
    end = tagged_text.find(f"</{tag}>")
    if start == -1 or end == -1 or end <= start:
        raise ValueError("No <json> block found")

    return tagged_text[start + len(f"<{tag}>"):end].strip()


def _safe_json_loads(s: str):
    try:
        return json.loads(s)
    except Exception as e:
        raise ValueError(f"JSON parse failed: {e}")


# ---------------------------------------------------------
# MAIN EXTRACTOR
# ---------------------------------------------------------
class SyllabusTNService:

    @staticmethod
    def _client():
        api = current_app.config.get("GROQ_API_KEY")
        return Groq(api_key=api)

    @staticmethod
    def _model():
        return current_app.config.get("GROQ_LLAMA_MODEL") or "llama3-70b-8192"

    # -----------------------
    # FILE PARSER (PDF & DOCX)
    # -----------------------
    @staticmethod
    def extract_text(path):
        ext = path.lower().split(".")[-1]

        # PDF
        if ext == "pdf":
            with pdfplumber.open(path) as pdf:
                pages = []
                for p in pdf.pages:
                    t = p.extract_text()
                    if t:
                        pages.append(markdownify.markdownify(t, heading_style="ATX"))
            return "\n".join(pages)

        # DOCX
        if ext in ["doc", "docx"]:
            d = docx.Document(path)
            return "\n".join([clean_utf(p.text) for p in d.paragraphs])

        return ""

    # -----------------------
    # ONE SINGLE LLM CALL
    # -----------------------
    @staticmethod
    def ask_llm(text):

        client = SyllabusTNService._client()

        prompt = f"""
You are a strict JSON extractor for Tunisian university syllabus.

Extract ALL the following IN ONE SINGLE JSON:

<json>
{{
  "administrative": {{
    "module_name": "",
    "code_ue": "",
    "code_ecue": "",
    "field": "",
    "department": "",
    "option": "",
    "volume_presentiel": "",
    "volume_personnel": "",
    "coefficient": 0,
    "credits": 0,
    "responsible": "",
    "teachers": []
  }},
  "aaa": [
    {{"AA#": 1, "description": ""}}
  ],
  "chapters": [
    {{
      "chapter": "",
      "sections": ["", ""]
    }}
  ],
  "evaluation": {{
    "methods": [],
    "criteria": [],
    "measures": [],
    "final_grade_formula": ""
  }},
  "bibliography": []
}}
</json>

Rules:
- Return ONLY JSON inside <json></json>.
- DO NOT invent AAP. AAP is handled separately.
- Respect accents (é, à, è).

TEXT:
{text}
"""

        response = client.chat.completions.create(
            model=SyllabusTNService._model(),
            messages=[
                {"role": "system", "content": "Return ONLY JSON inside <json></json>."},
                {"role": "user", "content": prompt}
            ],
            temperature=0
        )

        content = response.choices[0].message.content

        if "<json>" not in content:
            logger.error("LLM returned no <json> block")
            return {}

        try:
            block = content.split("<json>")[1].split("</json>")[0].strip()
            data = json.loads(block)
            return clean_json(data)

        except Exception as e:
            logger.error(f"JSON parse failed: {e}\nCONTENT={content}")
            return {}

    # -----------------------
    # MASTER EXTRACTION
    # -----------------------
    @staticmethod
    def extract_tn_syllabus(file_path):

        text = SyllabusTNService.extract_text(file_path)

        # ONE LLM CALL for everything except AAP
        llm_data = SyllabusTNService.ask_llm(text)

        # AAP from OCR detector
        aap = extract_aap_from_pdf(file_path)

        # Build final JSON
        result = {
            "administrative": llm_data.get("administrative", {}),
            "aaa": llm_data.get("aaa", []),
            "aap": aap,
            "mapping": [],
            "chapters": llm_data.get("chapters", []),
            "evaluation": llm_data.get("evaluation", {}),
            "bibliography": llm_data.get("bibliography", []),
        }

        return clean_json(result)

    @staticmethod
    def classify_chapters_sections_to_aaa(extracted: dict) -> dict:
        """
        Input: extracted TN syllabus JSON (administrative/aaa/chapters/...)
        Output: extracted + new field extracted["aaa_classification"]
        """
        client = SyllabusTNService._client()

        aaa_list = extracted.get("aaa", []) or []
        chapters = extracted.get("chapters", []) or []

        # Text AAA
        aaa_text = "\n".join([f'AA#{a.get("AA#", "")}: {a.get("description", "")}' for a in aaa_list])

        # Build chapters/sections text
        # chapters is like: [{"chapter":"...", "sections":["...", "..."]}]
        # We'll number them to have stable IDs
        ch_lines = []
        for i, ch in enumerate(chapters, start=1):
            ch_title = ch.get("chapter", "").strip()
            ch_lines.append(f"CHAPTER#{i}: {ch_title}")

            secs = ch.get("sections", []) or []
            for j, sec in enumerate(secs, start=1):
                sec_txt = str(sec).strip()
                ch_lines.append(f"  SECTION#{i}.{j}: {sec_txt}")

        chapters_text = "\n".join(ch_lines)

        prompt = f"""
[INST]
Tu es un assistant intelligent qui fait une classification sémantique (pas juste mots-clés).
Objectif: associer des sections et chapitres à des AAA (Acquis d’apprentissage) pertinents.

Voici la liste des AAA disponibles:
{aaa_text}

Voici le plan du cours (chapitres + sections) à classer:
{chapters_text}

Tâche:
1) Pour chaque CHAPTER#, donne la liste des AA# correspondants (au moins 1).
2) Pour chaque SECTION# (i.j), donne aussi la liste des AA# correspondants (au moins 1).
3) Utilise le sens global (concepts implicites) pas seulement les mots.
4) Si un item correspond à plusieurs AAA, retourne-les tous.

Règles de sortie:
- Retourne uniquement un JSON valide dans <json></json>
- Format EXACT:

<json>
{{
  "chapters": [
    {{
      "chapter_index": 1,
      "chapter_title": "...",
      "AA#": [1,2],
      "AADescription": ["...", "..."],
      "sections": [
        {{
          "section_index": "1.1",
          "section_title": "...",
          "AA#": [2],
          "AADescription": ["..."]
        }}
      ]
    }}
  ]
}}
</json>
[/INST]
"""

        response = client.chat.completions.create(
            model=SyllabusTNService._model(),
            messages=[{"role": "user", "content": prompt}],
            temperature=0,
            max_tokens=4000
        )

        content = response.choices[0].message.content
        block = _extract_json_block(content, "json")
        classification = _safe_json_loads(block)

        # attach to extracted (non destructive)
        extracted = dict(extracted)
        extracted["aaa_classification"] = classification
        return clean_json(extracted)